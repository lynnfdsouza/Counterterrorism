# Regression Analysis 1: Linear Regression for GTI Score
print("=== LINEAR REGRESSION ANALYSIS: GTI SCORE ===\n")

# GTI Score regression
y_score = yearly_data['Score'].values

# Fit linear regression
lr_score = LinearRegression()
lr_score.fit(X, y_score)

# Calculate metrics
score_pred = lr_score.predict(X)
r2_score_linear = r2_score(y_score, score_pred)
rmse_score = np.sqrt(mean_squared_error(y_score, score_pred))
mae_score = mean_absolute_error(y_score, score_pred)

print(f"Linear Regression Results for GTI Score:")
print(f"R² Score: {r2_score_linear:.4f}")
print(f"RMSE: {rmse_score:.4f}")
print(f"MAE: {mae_score:.4f}")
print(f"Slope: {lr_score.coef_[0]:.6f}")
print(f"Intercept: {lr_score.intercept_:.4f}")

# Statistical significance test
n = len(y_score)
t_stat = lr_score.coef_[0] / (rmse_score / np.sqrt(np.sum((X.flatten() - X.mean())**2)))
p_value = 2 * (1 - stats.t.cdf(abs(t_stat), n-2))
print(f"T-statistic: {t_stat:.4f}")
print(f"P-value: {p_value:.6f}")

if p_value < 0.05:
    print("✓ Slope is statistically significant")
else:
    print("✗ Slope is not statistically significant")

# Extrapolation for GTI Score (2023-2030)
future_years = np.arange(2023, 2031).reshape(-1, 1)
future_score_pred = lr_score.predict(future_years)

print(f"\nGTI Score Extrapolations (Linear):")
for i, year in enumerate(range(2023, 2031)):
    print(f"{year}: {future_score_pred[i]:.3f}")

# Calculate prediction intervals (95% confidence)
mse = mean_squared_error(y_score, score_pred)
x_mean = X.mean()
sxx = np.sum((X.flatten() - x_mean)**2)

prediction_intervals = []
for future_year in future_years:
    x_new = future_year[0]
    se_pred = np.sqrt(mse * (1 + 1/n + (x_new - x_mean)**2 / sxx))
    t_critical = stats.t.ppf(0.975, n-2)
    pred_value = lr_score.predict([[x_new]])[0]
    
    lower_bound = pred_value - t_critical * se_pred
    upper_bound = pred_value + t_critical * se_pred
    
    prediction_intervals.append((lower_bound, upper_bound))

print(f"\nGTI Score with 95% Prediction Intervals:")
for i, year in enumerate(range(2023, 2031)):
    pred_val = future_score_pred[i]
    lower, upper = prediction_intervals[i]
    print(f"{year}: {pred_val:.3f} ({lower:.3f} - {upper:.3f})")