import plotly.graph_objects as go
import plotly.express as px

# Data for the chart
data = [
    {"Model": "Linear", "R_Squared": 0.1072, "Performance": "Poor"},
    {"Model": "Multiple Linear", "R_Squared": 0.4161, "Performance": "Moderate"},
    {"Model": "Polynomial Degree 2", "R_Squared": 0.7348, "Performance": "Good"},
    {"Model": "Polynomial Degree 3", "R_Squared": 0.8272, "Performance": "Excellent"}
]

# Abbreviate long model names to stay under 15 character limit
model_names = []
r_squared_values = []
performance_levels = []

for item in data:
    model = item["Model"]
    if "Polynomial Degree" in model:
        # Abbreviate to "Poly Deg X"
        model = model.replace("Polynomial Degree", "Poly Deg")
    model_names.append(model)
    r_squared_values.append(item["R_Squared"])
    performance_levels.append(item["Performance"])

# Define colors for each performance level
color_map = {
    "Poor": "#DB4545",      # Bright red
    "Moderate": "#D2BA4C",  # Moderate yellow
    "Good": "#2E8B57",      # Sea green
    "Excellent": "#1FB8CD"  # Strong cyan
}

colors = [color_map[perf] for perf in performance_levels]

# Create the bar chart
fig = go.Figure()

# Add bars
fig.add_trace(go.Bar(
    x=model_names,
    y=r_squared_values,
    marker_color=colors,
    text=[f"{val:.3f}" for val in r_squared_values],
    textposition='outside',
    showlegend=False
))

# Add horizontal reference line at R² = 0.7
fig.add_hline(y=0.7, line_dash="dash", line_color="gray", 
              annotation_text="R² = 0.7", annotation_position="right")

# Update layout
fig.update_layout(
    title="R² Values by Model",
    xaxis_title="Model",
    yaxis_title="R² Value",
    yaxis=dict(range=[0, max(r_squared_values) * 1.1])
)

# Update traces for better display
fig.update_traces(cliponaxis=False)

# Save as PNG and SVG
fig.write_image("r_squared_comparison.png")
fig.write_image("r_squared_comparison.svg", format="svg")

fig.show()