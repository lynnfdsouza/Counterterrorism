import pandas as pd
import plotly.graph_objects as go
import json

# Load the data from JSON
data_json = [
  {"Year": 2012, "Historical": 2.447, "Type": "Historical"},
  {"Year": 2013, "Historical": 2.364, "Type": "Historical"},
  {"Year": 2014, "Historical": 2.350, "Type": "Historical"},
  {"Year": 2015, "Historical": 2.545, "Type": "Historical"},
  {"Year": 2016, "Historical": 2.578, "Type": "Historical"},
  {"Year": 2017, "Historical": 2.593, "Type": "Historical"},
  {"Year": 2018, "Historical": 2.630, "Type": "Historical"},
  {"Year": 2019, "Historical": 2.588, "Type": "Historical"},
  {"Year": 2020, "Historical": 2.376, "Type": "Historical"},
  {"Year": 2021, "Historical": 2.232, "Type": "Historical"},
  {"Year": 2022, "Historical": 2.168, "Type": "Historical"},
  {"Year": 2023, "Linear": 2.350, "Polynomial_2": 2.001, "Polynomial_3": 1.791, "Lower_CI": 1.969, "Upper_CI": 2.731, "Type": "Forecast"},
  {"Year": 2024, "Linear": 2.334, "Polynomial_2": 1.811, "Polynomial_3": 1.391, "Lower_CI": 1.938, "Upper_CI": 2.731, "Type": "Forecast"},
  {"Year": 2025, "Linear": 2.319, "Polynomial_2": 1.594, "Polynomial_3": 0.884, "Lower_CI": 1.905, "Upper_CI": 2.733, "Type": "Forecast"},
  {"Year": 2026, "Linear": 2.303, "Polynomial_2": 1.350, "Polynomial_3": 0.257, "Lower_CI": 1.871, "Upper_CI": 2.736, "Type": "Forecast"},
  {"Year": 2027, "Linear": 2.288, "Polynomial_2": 1.079, "Polynomial_3": -0.499, "Lower_CI": 1.835, "Upper_CI": 2.740, "Type": "Forecast"},
  {"Year": 2028, "Linear": 2.272, "Polynomial_2": 0.781, "Polynomial_3": -1.398, "Lower_CI": 1.799, "Upper_CI": 2.746, "Type": "Forecast"},
  {"Year": 2029, "Linear": 2.257, "Polynomial_2": 0.456, "Polynomial_3": -2.451, "Lower_CI": 1.761, "Upper_CI": 2.753, "Type": "Forecast"},
  {"Year": 2030, "Linear": 2.241, "Polynomial_2": 0.104, "Polynomial_3": -3.669, "Lower_CI": 1.723, "Upper_CI": 2.760, "Type": "Forecast"}
]

df = pd.DataFrame(data_json)

# Split historical and forecast data
historical_df = df[df['Type'] == 'Historical'].copy()
forecast_df = df[df['Type'] == 'Forecast'].copy()

# Create the figure
fig = go.Figure()

# Add historical data
fig.add_trace(go.Scatter(
    x=historical_df['Year'],
    y=historical_df['Historical'],
    mode='lines+markers',
    name='Historical',
    line=dict(color='#1FB8CD', width=3),
    marker=dict(size=6)
))

# Add confidence interval (fill area)
fig.add_trace(go.Scatter(
    x=forecast_df['Year'],
    y=forecast_df['Upper_CI'],
    mode='lines',
    line=dict(width=0),
    showlegend=False,
    hoverinfo='skip'
))

fig.add_trace(go.Scatter(
    x=forecast_df['Year'],
    y=forecast_df['Lower_CI'],
    mode='lines',
    fill='tonexty',
    fillcolor='rgba(219, 69, 69, 0.2)',
    line=dict(width=0),
    name='Confidence Int',
    showlegend=True,
    hoverinfo='skip'
))

# Add Linear forecast
fig.add_trace(go.Scatter(
    x=forecast_df['Year'],
    y=forecast_df['Linear'],
    mode='lines',
    name='Linear',
    line=dict(color='#DB4545', width=2, dash='solid')
))

# Add Polynomial degree 2 forecast
fig.add_trace(go.Scatter(
    x=forecast_df['Year'],
    y=forecast_df['Polynomial_2'],
    mode='lines',
    name='Polynomial 2',
    line=dict(color='#2E8B57', width=2, dash='dash')
))

# Add Polynomial degree 3 forecast
fig.add_trace(go.Scatter(
    x=forecast_df['Year'],
    y=forecast_df['Polynomial_3'],
    mode='lines',
    name='Polynomial 3',
    line=dict(color='#5D878F', width=2, dash='dot')
))

# Update layout
fig.update_layout(
    title='GTI Forecast Models 2012-2030',
    xaxis_title='Year',
    yaxis_title='GTI Score',
    legend=dict(orientation='v', yanchor='top', y=1, xanchor='left', x=1.01)
)

# Update axes
fig.update_xaxes(showgrid=True)
fig.update_yaxes(showgrid=True)

# Save the chart
fig.write_image("gti_forecast_chart.png")
fig.write_image("gti_forecast_chart.svg", format="svg")