import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import numpy as np

# Load the data
df = pd.read_excel("Global-Terrorism-Index-2023.xlsx")

# Remove any rows with missing values in the relevant columns
df_clean = df.dropna(subset=['Incidents', 'Score'])

# Prepare the data for regression
X = df_clean['Incidents'].values.reshape(-1, 1)
y = df_clean['Score'].values

# Fit linear regression
reg_model = LinearRegression()
reg_model.fit(X, y)
y_pred = reg_model.predict(X)

# Calculate R²
r2 = r2_score(y, y_pred)

# Create scatter plot
fig = go.Figure()

# Add scatter points
fig.add_trace(go.Scatter(
    x=df_clean['Incidents'],
    y=df_clean['Score'],
    mode='markers',
    name='Data Points',
    marker=dict(color='#1FB8CD', size=6, opacity=0.7),
    hovertemplate='Incidents: %{x}<br>GTI Score: %{y:.2f}<extra></extra>'
))

# Add regression line
x_range = np.linspace(df_clean['Incidents'].min(), df_clean['Incidents'].max(), 100)
y_range = reg_model.predict(x_range.reshape(-1, 1))

fig.add_trace(go.Scatter(
    x=x_range,
    y=y_range,
    mode='lines',
    name=f'Reg Line (R²={r2:.3f})',
    line=dict(color='#DB4545', width=2)
))

# Update layout
fig.update_layout(
    title='Incidents vs GTI Score',
    xaxis_title='Incidents',
    yaxis_title='GTI Score',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    showlegend=True
)

# Update traces for better rendering
fig.update_traces(cliponaxis=False)

# Save the chart as both PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

print(f"Regression analysis complete:")
print(f"R² = {r2:.4f}")
print(f"Number of data points: {len(df_clean)}")
print(f"Correlation coefficient: {np.corrcoef(df_clean['Incidents'], df_clean['Score'])[0,1]:.4f}")