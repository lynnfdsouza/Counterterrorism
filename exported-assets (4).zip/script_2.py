# Regression Analysis 2: Polynomial Regression for better fit
print("=== POLYNOMIAL REGRESSION ANALYSIS ===\n")

# Test polynomial degrees 2 and 3
poly_results = {}
for degree in [2, 3]:
    poly_features = PolynomialFeatures(degree=degree)
    X_poly = poly_features.fit_transform(X)
    
    # Fit polynomial regression
    lr_poly = LinearRegression()
    lr_poly.fit(X_poly, y_score)
    
    # Predictions
    score_pred_poly = lr_poly.predict(X_poly)
    r2_poly = r2_score(y_score, score_pred_poly)
    rmse_poly = np.sqrt(mean_squared_error(y_score, score_pred_poly))
    
    poly_results[degree] = {
        'model': lr_poly,
        'features': poly_features,
        'r2': r2_poly,
        'rmse': rmse_poly,
        'predictions': score_pred_poly
    }
    
    print(f"Polynomial Degree {degree}:")
    print(f"  R² Score: {r2_poly:.4f}")
    print(f"  RMSE: {rmse_poly:.4f}")
    
    # Future predictions
    future_years_poly = poly_features.transform(future_years)
    future_pred_poly = lr_poly.predict(future_years_poly)
    
    print(f"  Extrapolations (2023-2026):")
    for i, year in enumerate(range(2023, 2027)):
        print(f"    {year}: {future_pred_poly[i]:.3f}")
    print()

# Select best polynomial model
best_degree = max(poly_results.keys(), key=lambda k: poly_results[k]['r2'])
best_poly_model = poly_results[best_degree]

print(f"Best polynomial model: Degree {best_degree} (R² = {best_poly_model['r2']:.4f})")