# Regression Analysis 3: Multiple Variable Regression
print("=== MULTIPLE REGRESSION ANALYSIS ===\n")

# Prepare data for multiple regression
# Use incidents, fatalities, injuries as predictors for GTI Score
country_level_data = df.groupby(['Country', 'Year']).agg({
    'Score': 'first',
    'Incidents': 'first',
    'Fatalities': 'first',
    'Injuries': 'first',
    'Hostages': 'first'
}).reset_index()

# Remove zero-incident countries for meaningful regression
active_terrorism = country_level_data[country_level_data['Incidents'] > 0].copy()

print(f"Multiple regression dataset: {len(active_terrorism)} observations")
print("Predictors: Incidents, Fatalities, Injuries, Hostages")

# Features and target
X_multi = active_terrorism[['Incidents', 'Fatalities', 'Injuries', 'Hostages']].values
y_multi = active_terrorism['Score'].values

# Split data for training and testing
X_train, X_test, y_train, y_test = train_test_split(X_multi, y_multi, test_size=0.2, random_state=42)

# Standardize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Fit multiple regression models
models = {
    'Linear': LinearRegression(),
    'Ridge': Ridge(alpha=1.0),
    'Lasso': Lasso(alpha=0.1)
}

regression_results = {}
for name, model in models.items():
    # Fit model
    model.fit(X_train_scaled, y_train)
    
    # Predictions
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)
    
    # Metrics
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    
    regression_results[name] = {
        'model': model,
        'train_r2': train_r2,
        'test_r2': test_r2,
        'train_rmse': train_rmse,
        'test_rmse': test_rmse
    }
    
    print(f"{name} Regression:")
    print(f"  Training R²: {train_r2:.4f}")
    print(f"  Testing R²: {test_r2:.4f}")
    print(f"  Training RMSE: {train_rmse:.4f}")
    print(f"  Testing RMSE: {test_rmse:.4f}")
    
    # Feature importance (coefficients)
    if hasattr(model, 'coef_'):
        feature_names = ['Incidents', 'Fatalities', 'Injuries', 'Hostages']
        print(f"  Coefficients:")
        for i, coef in enumerate(model.coef_):
            print(f"    {feature_names[i]}: {coef:.6f}")
    print()

# Select best model
best_model_name = max(regression_results.keys(), key=lambda k: regression_results[k]['test_r2'])
best_multi_model = regression_results[best_model_name]['model']
print(f"Best multiple regression model: {best_model_name}")
print(f"Test R²: {regression_results[best_model_name]['test_r2']:.4f}")