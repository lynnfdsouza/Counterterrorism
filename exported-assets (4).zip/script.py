import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.model_selection import train_test_split
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# Load the dataset
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

print("=== REGRESSION ANALYSIS AND EXTRAPOLATION ===\n")

# Prepare time series data for regression
yearly_data = df.groupby('Year').agg({
    'Score': 'mean',
    'Incidents': 'sum',
    'Fatalities': 'sum',
    'Injuries': 'sum',
    'Hostages': 'sum'
}).reset_index()

print("Yearly aggregated data for regression:")
print(yearly_data)

# Create features for regression
X = yearly_data['Year'].values.reshape(-1, 1)
years = yearly_data['Year'].values

print(f"\nTime period: {years.min()} - {years.max()} ({len(years)} observations)")
print("Target variables: GTI Score, Incidents, Fatalities, Injuries, Hostages")