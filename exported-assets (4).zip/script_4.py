# Comprehensive Extrapolation Analysis
print("=== COMPREHENSIVE EXTRAPOLATION ANALYSIS ===\n")

# Time series regression for all metrics
metrics = ['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']
extrapolation_results = {}

for metric in metrics:
    print(f"--- {metric.upper()} EXTRAPOLATION ---")
    
    y = yearly_data[metric].values
    
    # Linear regression
    lr = LinearRegression()
    lr.fit(X, y)
    
    # Metrics
    y_pred = lr.predict(X)
    r2 = r2_score(y, y_pred)
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    
    # Statistical significance
    t_stat = lr.coef_[0] / (rmse / np.sqrt(np.sum((X.flatten() - X.mean())**2)))
    p_value = 2 * (1 - stats.t.cdf(abs(t_stat), len(y)-2))
    
    print(f"Linear Regression R²: {r2:.4f}")
    print(f"Slope: {lr.coef_[0]:.4f} per year")
    print(f"P-value: {p_value:.4f}")
    
    # Future predictions
    future_pred = lr.predict(future_years)
    
    # Store results
    extrapolation_results[metric] = {
        'model': lr,
        'r2': r2,
        'slope': lr.coef_[0],
        'p_value': p_value,
        'significant': p_value < 0.05,
        'predictions': future_pred
    }
    
    print(f"2025 Prediction: {future_pred[2]:.2f}")
    print(f"2030 Prediction: {future_pred[7]:.2f}")
    
    # Calculate percentage change from 2022 to 2030
    current_value = yearly_data[yearly_data['Year'] == 2022][metric].iloc[0]
    pred_2030 = future_pred[7]
    pct_change = ((pred_2030 - current_value) / current_value) * 100
    print(f"2022-2030 Change: {pct_change:.1f}%")
    print()

# Summary of trends
print("=== TREND SUMMARY ===")
for metric, results in extrapolation_results.items():
    trend = "Increasing" if results['slope'] > 0 else "Decreasing"
    significance = "Significant" if results['significant'] else "Not Significant"
    print(f"{metric}: {trend} trend ({significance}, R²={results['r2']:.3f})")

# Export predictions
future_years_flat = future_years.flatten()
predictions_df = pd.DataFrame({'Year': future_years_flat})

for metric, results in extrapolation_results.items():
    predictions_df[f'{metric}_Prediction'] = results['predictions']

predictions_df.to_csv('Regression_Extrapolations.csv', index=False)
print(f"\nExtrapolations exported to 'Regression_Extrapolations.csv'")