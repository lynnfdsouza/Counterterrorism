import pandas as pd
import plotly.graph_objects as go

# Load the data
data = [
  {"Year": 2022, "Score": 2.168, "Incidents": 3955, "Fatalities": 6701, "Injuries": 5993, "Type": "Historical"},
  {"Year": 2023, "Score": 2.350, "Incidents": 4701, "Fatalities": 6310, "Injuries": 4749, "Type": "Forecast"},
  {"Year": 2024, "Score": 2.334, "Incidents": 4747, "Fatalities": 5920, "Injuries": 3505, "Type": "Forecast"},
  {"Year": 2025, "Score": 2.319, "Incidents": 4794, "Fatalities": 5530, "Injuries": 2261, "Type": "Forecast"},
  {"Year": 2026, "Score": 2.303, "Incidents": 4840, "Fatalities": 5139, "Injuries": 1017, "Type": "Forecast"},
  {"Year": 2027, "Score": 2.288, "Incidents": 4886, "Fatalities": 4749, "Injuries": -227, "Type": "Forecast"},
  {"Year": 2028, "Score": 2.272, "Incidents": 4932, "Fatalities": 4358, "Injuries": -1471, "Type": "Forecast"},
  {"Year": 2029, "Score": 2.257, "Incidents": 4979, "Fatalities": 3968, "Injuries": -2715, "Type": "Forecast"},
  {"Year": 2030, "Score": 2.241, "Incidents": 5025, "Fatalities": 3577, "Injuries": -3959, "Type": "Forecast"}
]

df = pd.DataFrame(data)

# Normalize each metric to 2022 baseline (as index where 2022 = 100)
baseline_values = df[df['Year'] == 2022].iloc[0]

df['Score_Idx'] = (df['Score'] / baseline_values['Score']) * 100
df['Incident_Idx'] = (df['Incidents'] / baseline_values['Incidents']) * 100
df['Fatal_Idx'] = (df['Fatalities'] / baseline_values['Fatalities']) * 100
df['Injury_Idx'] = (df['Injuries'] / baseline_values['Injuries']) * 100

# Create the chart
fig = go.Figure()

# Historical data (2022) and forecast data (2023-2030)
hist_df = df[df['Type'] == 'Historical']
fore_df = df[df['Type'] == 'Forecast']

# Add lines for each metric - using solid lines for all but distinguishing by color
fig.add_trace(go.Scatter(x=df['Year'], y=df['Score_Idx'], 
                         mode='lines+markers', name='Score',
                         line=dict(color='#1FB8CD', width=3),
                         marker=dict(size=6)))

fig.add_trace(go.Scatter(x=df['Year'], y=df['Incident_Idx'], 
                         mode='lines+markers', name='Incidents',
                         line=dict(color='#DB4545', width=3),
                         marker=dict(size=6)))

fig.add_trace(go.Scatter(x=df['Year'], y=df['Fatal_Idx'], 
                         mode='lines+markers', name='Fatalities',
                         line=dict(color='#2E8B57', width=3),
                         marker=dict(size=6)))

fig.add_trace(go.Scatter(x=df['Year'], y=df['Injury_Idx'], 
                         mode='lines+markers', name='Injuries',
                         line=dict(color='#5D878F', width=3),
                         marker=dict(size=6)))

# Add vertical line to separate historical from forecast
fig.add_vline(x=2022.5, line_dash="dash", line_color="rgba(128,128,128,0.5)")

# Update layout
fig.update_layout(
    title="Terror Trends 2022-2030",
    xaxis_title="Year",
    yaxis_title="Index (2022=100)",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

fig.update_traces(cliponaxis=False)
fig.update_xaxes(dtick=1)

# Save as PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")