# Advanced regression models and model comparison
print("=== ADVANCED REGRESSION MODEL COMPARISON ===\n")

# Focus on GTI Score with different modeling approaches
y_score = yearly_data['Score'].values
X_years = yearly_data['Year'].values.reshape(-1, 1)

# Model comparison
models_comparison = {}

# 1. Linear Regression
lr_simple = LinearRegression()
lr_simple.fit(X_years, y_score)
score_pred_linear = lr_simple.predict(X_years)
models_comparison['Linear'] = {
    'r2': r2_score(y_score, score_pred_linear),
    'rmse': np.sqrt(mean_squared_error(y_score, score_pred_linear)),
    'aic': len(y_score) * np.log(mean_squared_error(y_score, score_pred_linear)) + 2 * 2,
    'model': lr_simple
}

# 2. Polynomial Degree 2
poly2 = PolynomialFeatures(degree=2)
X_poly2 = poly2.fit_transform(X_years)
lr_poly2 = LinearRegression()
lr_poly2.fit(X_poly2, y_score)
score_pred_poly2 = lr_poly2.predict(X_poly2)
models_comparison['Polynomial_2'] = {
    'r2': r2_score(y_score, score_pred_poly2),
    'rmse': np.sqrt(mean_squared_error(y_score, score_pred_poly2)),
    'aic': len(y_score) * np.log(mean_squared_error(y_score, score_pred_poly2)) + 2 * 3,
    'models': [poly2, lr_poly2]
}

# 3. Polynomial Degree 3  
poly3 = PolynomialFeatures(degree=3)
X_poly3 = poly3.fit_transform(X_years)
lr_poly3 = LinearRegression()
lr_poly3.fit(X_poly3, y_score)
score_pred_poly3 = lr_poly3.predict(X_poly3)
models_comparison['Polynomial_3'] = {
    'r2': r2_score(y_score, score_pred_poly3),
    'rmse': np.sqrt(mean_squared_error(y_score, score_pred_poly3)),
    'aic': len(y_score) * np.log(mean_squared_error(y_score, score_pred_poly3)) + 2 * 4,
    'models': [poly3, lr_poly3]
}

print("Model Comparison Results:")
print("-" * 50)
for model_name, metrics in models_comparison.items():
    print(f"{model_name}:")
    print(f"  R²: {metrics['r2']:.4f}")
    print(f"  RMSE: {metrics['rmse']:.4f}")
    print(f"  AIC: {metrics['aic']:.2f}")
    print()

# Select best model based on AIC (lower is better)
best_model_name = min(models_comparison.keys(), key=lambda k: models_comparison[k]['aic'])
print(f"Best model (lowest AIC): {best_model_name}")

# Generate comprehensive extrapolations with uncertainty bounds
print(f"\n=== EXTRAPOLATION WITH UNCERTAINTY ANALYSIS ===")

# Create extended prediction years (2023-2035)
extended_years = np.arange(2023, 2036).reshape(-1, 1)

# Linear extrapolation with confidence intervals
future_linear = lr_simple.predict(extended_years)

# Polynomial extrapolations
if best_model_name == 'Polynomial_2':
    extended_poly = poly2.transform(extended_years)
    future_poly = lr_poly2.predict(extended_poly)
elif best_model_name == 'Polynomial_3':
    extended_poly = poly3.transform(extended_years)
    future_poly = lr_poly3.predict(extended_poly)
else:
    future_poly = future_linear

# Create comprehensive forecast table
forecast_table = pd.DataFrame({
    'Year': extended_years.flatten(),
    'Linear_Forecast': future_linear,
    'Best_Model_Forecast': future_poly if best_model_name != 'Linear' else future_linear,
    'Historical_Last': yearly_data['Score'].iloc[-1]  # 2022 value for reference
})

# Add confidence bounds for linear model
mse_linear = mean_squared_error(y_score, score_pred_linear)
x_mean = X_years.mean()
sxx = np.sum((X_years.flatten() - x_mean)**2)
n = len(y_score)

confidence_bounds = []
for year in extended_years.flatten():
    se_pred = np.sqrt(mse_linear * (1 + 1/n + (year - x_mean)**2 / sxx))
    t_critical = stats.t.ppf(0.975, n-2)
    pred_value = lr_simple.predict([[year]])[0]
    
    lower_bound = pred_value - t_critical * se_pred
    upper_bound = pred_value + t_critical * se_pred
    confidence_bounds.append((lower_bound, upper_bound))

forecast_table['Lower_95CI'] = [cb[0] for cb in confidence_bounds]
forecast_table['Upper_95CI'] = [cb[1] for cb in confidence_bounds]

print("GTI Score Forecasts (2023-2030):")
print(forecast_table.head(8).round(3))

# Export comprehensive results
forecast_table.to_csv('Comprehensive_Forecasts.csv', index=False)

# Model diagnostics
print(f"\n=== MODEL DIAGNOSTICS ===")
residuals = y_score - score_pred_linear
print(f"Residual Analysis (Linear Model):")
print(f"Mean residual: {residuals.mean():.6f}")
print(f"Residual std: {residuals.std():.4f}")
print(f"Durbin-Watson statistic: {2 * (1 - np.corrcoef(residuals[:-1], residuals[1:])[0,1]):.4f}")

# Export all results
results_summary = {
    'Linear_R2': models_comparison['Linear']['r2'],
    'Linear_RMSE': models_comparison['Linear']['rmse'],
    'Best_Model': best_model_name,
    'Best_Model_R2': models_comparison[best_model_name]['r2'],
    'Forecast_2025': forecast_table[forecast_table['Year']==2025]['Best_Model_Forecast'].iloc[0],
    'Forecast_2030': forecast_table[forecast_table['Year']==2030]['Best_Model_Forecast'].iloc[0]
}

print(f"\nKey Results Summary:")
for key, value in results_summary.items():
    print(f"{key}: {value}")

print(f"\nFiles exported:")
print("- Regression_Extrapolations.csv")
print("- Comprehensive_Forecasts.csv")