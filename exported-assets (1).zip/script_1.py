# Data preprocessing - handle outliers and standardize
# First, let's check for data quality issues
print("Data quality check:")
print("Missing values:", X.isnull().sum())
print("Zero values count:")
print((X == 0).sum())

# Remove duplicate countries (seems there are some data quality issues)
country_data_clean = country_data.drop_duplicates(subset=['Country'])
X_clean = country_data_clean[features].copy()

print(f"\nAfter removing duplicates: {X_clean.shape[0]} countries")
print("\nCleaned data statistics:")
print(X_clean.describe())

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_clean)

print("\nFeatures after standardization (first 5 rows):")
print(X_scaled[:5])