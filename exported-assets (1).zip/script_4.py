# Create detailed cluster analysis and export results
print("=== DETAILED CLUSTER PROFILES (K=5) ===\n")

cluster_profiles = {}
for i in range(5):
    cluster_data = country_data_clean[country_data_clean['Cluster_K5'] == i]
    
    profile = {
        'Cluster_Name': '',
        'Count': len(cluster_data),
        'Countries': cluster_data['Country'].tolist(),
        'Avg_Score': cluster_data['Score'].mean(),
        'Avg_Incidents': cluster_data['Incidents'].mean(),
        'Avg_Fatalities': cluster_data['Fatalities'].mean(),
        'Avg_Injuries': cluster_data['Injuries'].mean(),
        'Avg_Hostages': cluster_data['Hostages'].mean()
    }
    
    # Assign meaningful cluster names based on characteristics
    if profile['Avg_Score'] < 2:
        profile['Cluster_Name'] = 'Low Risk'
    elif profile['Avg_Score'] < 5:
        profile['Cluster_Name'] = 'Moderate Risk'
    elif profile['Avg_Score'] < 8:
        profile['Cluster_Name'] = 'High Risk'
    else:
        if profile['Count'] == 1 and 'Iraq' in profile['Countries']:
            profile['Cluster_Name'] = 'Extreme Risk (Iraq)'
        elif profile['Count'] == 1 and 'Afghanistan' in profile['Countries']:
            profile['Cluster_Name'] = 'Extreme Risk (Afghanistan)'
        else:
            profile['Cluster_Name'] = 'Very High Risk'
    
    cluster_profiles[i] = profile
    
    print(f"Cluster {i}: {profile['Cluster_Name']}")
    print(f"Countries ({profile['Count']}): {', '.join(profile['Countries'][:5])}" + 
          ("..." if len(profile['Countries']) > 5 else ""))
    print(f"Avg GTI Score: {profile['Avg_Score']:.2f}")
    print(f"Avg Incidents: {profile['Avg_Incidents']:.0f}")
    print(f"Avg Fatalities: {profile['Avg_Fatalities']:.0f}")
    print(f"Avg Injuries: {profile['Avg_Injuries']:.0f}")
    print(f"Avg Hostages: {profile['Avg_Hostages']:.0f}")
    print("-" * 50)

# Export clustering results
country_data_clean.to_csv('GTI_Clustering_Results.csv', index=False)
print("Clustering results exported to 'GTI_Clustering_Results.csv'")

# Create summary statistics for visualization
cluster_summary = pd.DataFrame([
    {
        'Cluster': i,
        'Cluster_Name': cluster_profiles[i]['Cluster_Name'],
        'Count': cluster_profiles[i]['Count'],
        'Avg_Score': cluster_profiles[i]['Avg_Score'],
        'Avg_Incidents': cluster_profiles[i]['Avg_Incidents'],
        'Avg_Fatalities': cluster_profiles[i]['Avg_Fatalities'],
        'Avg_Injuries': cluster_profiles[i]['Avg_Injuries']
    }
    for i in range(5)
])

print("\nCluster Summary:")
print(cluster_summary.round(2))