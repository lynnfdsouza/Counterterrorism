# Create detailed analysis of each cluster with specific country examples
print("=== COMPREHENSIVE K-MEANS CLUSTERING ANALYSIS ===\n")

# Detailed breakdown of each cluster
cluster_details = {
    0: {
        'name': 'Low Risk Countries',
        'description': 'Countries with minimal terrorism activity',
        'characteristics': 'GTI scores below 2.0, very few incidents, minimal casualties'
    },
    1: {
        'name': 'Very High Risk Countries', 
        'description': 'Major terrorism-affected nations excluding Iraq and Afghanistan',
        'characteristics': 'GTI scores around 8.0, thousands of incidents, high casualties'
    },
    2: {
        'name': 'Extreme Risk - Afghanistan',
        'description': 'Afghanistan as a unique case with persistent conflict',
        'characteristics': 'Single-country cluster due to sustained high-level terrorism'
    },
    3: {
        'name': 'Extreme Risk - Iraq',
        'description': 'Iraq as the most terrorism-affected country globally', 
        'characteristics': 'Highest GTI score (9.33), most incidents and injuries'
    },
    4: {
        'name': 'High Risk Countries',
        'description': 'Countries with significant but manageable terrorism threats',
        'characteristics': 'GTI scores around 5.0, moderate incident levels'
    }
}

for i in range(5):
    cluster_data = country_data_clean[country_data_clean['Cluster_K5'] == i]
    print(f"CLUSTER {i}: {cluster_details[i]['name']}")
    print(f"Description: {cluster_details[i]['description']}")
    print(f"Characteristics: {cluster_details[i]['characteristics']}")
    print(f"Number of countries: {len(cluster_data)}")
    
    if len(cluster_data) <= 10:
        print(f"All countries: {', '.join(cluster_data['Country'].tolist())}")
    else:
        top_5 = cluster_data.nlargest(5, 'Score')['Country'].tolist()
        bottom_5 = cluster_data.nsmallest(5, 'Score')['Country'].tolist()
        print(f"Highest risk in cluster: {', '.join(top_5)}")
        print(f"Lowest risk in cluster: {', '.join(bottom_5)}")
    
    print(f"Score range: {cluster_data['Score'].min():.2f} - {cluster_data['Score'].max():.2f}")
    print(f"Incident range: {cluster_data['Incidents'].min()} - {cluster_data['Incidents'].max()}")
    print("="*60 + "\n")

# Calculate cluster centers in original scale
cluster_centers = []
for i in range(5):
    cluster_data = country_data_clean[country_data_clean['Cluster_K5'] == i]
    center = cluster_data[features].mean()
    cluster_centers.append(center)

centers_df = pd.DataFrame(cluster_centers, columns=features)
centers_df.index = [f'Cluster_{i}' for i in range(5)]
centers_df.to_csv('Cluster_Centers.csv')

print("Cluster centers (average values):")
print(centers_df.round(2))