import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

# Create country-level aggregated data for clustering
country_data = df.groupby(['Country', 'iso3c']).agg({
    'Score': 'mean',
    'Incidents': 'sum',
    'Fatalities': 'sum',
    'Injuries': 'sum',
    'Hostages': 'sum'
}).reset_index()

print("Country-level aggregated data shape:", country_data.shape)
print("\nFirst 10 countries:")
print(country_data.head(10))

# Select features for clustering
features = ['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']
X = country_data[features].copy()

print("\nFeatures for clustering:")
print(X.describe())