import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd

# Create the data
data = [
    {"K": 2, "Inertia": 366.39, "Silhouette_Score": 0.844},
    {"K": 3, "Inertia": 201.89, "Silhouette_Score": 0.692},
    {"K": 4, "Inertia": 127.05, "Silhouette_Score": 0.641},
    {"K": 5, "Inertia": 73.62, "Silhouette_Score": 0.640},
    {"K": 6, "Inertia": 43.16, "Silhouette_Score": 0.628},
    {"K": 7, "Inertia": 32.69, "Silhouette_Score": 0.574},
    {"K": 8, "Inertia": 26.17, "Silhouette_Score": 0.575},
    {"K": 9, "Inertia": 21.24, "Silhouette_Score": 0.571},
    {"K": 10, "Inertia": 18.43, "Silhouette_Score": 0.568}
]

df = pd.DataFrame(data)

# Create figure with secondary y-axis
fig = make_subplots(specs=[[{"secondary_y": True}]])

# Add Inertia trace (primary y-axis)
fig.add_trace(
    go.Scatter(
        x=df['K'],
        y=df['Inertia'],
        mode='lines+markers',
        name='Inertia',
        line=dict(color='#1FB8CD', width=3),
        marker=dict(size=8)
    ),
    secondary_y=False,
)

# Add Silhouette Score trace (secondary y-axis)
fig.add_trace(
    go.Scatter(
        x=df['K'],
        y=df['Silhouette_Score'],
        mode='lines+markers',
        name='Silhouette',
        line=dict(color='#DB4545', width=3),
        marker=dict(size=8)
    ),
    secondary_y=True,
)

# Highlight optimal K=2 point for Inertia
fig.add_trace(
    go.Scatter(
        x=[2],
        y=[366.39],
        mode='markers',
        name='Optimal K=2',
        marker=dict(
            size=12,
            color='#2E8B57',
            symbol='star',
            line=dict(color='white', width=2)
        ),
        showlegend=True
    ),
    secondary_y=False,
)

# Highlight optimal K=2 point for Silhouette Score
fig.add_trace(
    go.Scatter(
        x=[2],
        y=[0.844],
        mode='markers',
        name='K=2 Silhouette',
        marker=dict(
            size=12,
            color='#2E8B57',
            symbol='star',
            line=dict(color='white', width=2)
        ),
        showlegend=False
    ),
    secondary_y=True,
)

# Set x-axis title
fig.update_xaxes(title_text="K Values")

# Set y-axes titles
fig.update_yaxes(title_text="Inertia", secondary_y=False)
fig.update_yaxes(title_text="Silhouette", secondary_y=True)

# Update layout
fig.update_layout(
    title='Elbow Method Analysis',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update x-axis ticks
fig.update_xaxes(tickmode='linear', tick0=2, dtick=1)

# Update traces
fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image("elbow_chart.png")
fig.write_image("elbow_chart.svg", format="svg")