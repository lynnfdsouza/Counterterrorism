# Perform K-means clustering with optimal K and also with K=5 for more granular analysis
print("=== K-Means Clustering Analysis ===\n")

# Optimal K clustering (K=2)
kmeans_optimal = KMeans(n_clusters=2, random_state=42, n_init=10)
labels_optimal = kmeans_optimal.fit_predict(X_scaled)

# Alternative clustering with K=5 for more detailed segmentation
kmeans_5 = KMeans(n_clusters=5, random_state=42, n_init=10)
labels_5 = kmeans_5.fit_predict(X_scaled)

# Add cluster labels to the original data
country_data_clean['Cluster_K2'] = labels_optimal
country_data_clean['Cluster_K5'] = labels_5

# Analyze K=2 clustering
print("CLUSTERING RESULTS WITH K=2 (Optimal)")
print("="*50)
for i in range(2):
    cluster_countries = country_data_clean[country_data_clean['Cluster_K2'] == i]
    print(f"\nCluster {i}: {len(cluster_countries)} countries")
    print("Average characteristics:")
    print(cluster_countries[features].mean().round(2))
    print("Countries:", cluster_countries['Country'].tolist()[:10], "..." if len(cluster_countries) > 10 else "")

print("\n" + "="*50)
print("CLUSTERING RESULTS WITH K=5 (Detailed Segmentation)")
print("="*50)
for i in range(5):
    cluster_countries = country_data_clean[country_data_clean['Cluster_K5'] == i]
    print(f"\nCluster {i}: {len(cluster_countries)} countries")
    print("Average characteristics:")
    print(cluster_countries[features].mean().round(2))
    print("Top countries:", cluster_countries.nlargest(5, 'Score')['Country'].tolist())