import plotly.graph_objects as go
import pandas as pd
import numpy as np

# Data from the JSON
data = [
    {"Cluster": "Low Risk", "Score": 0.98, "Incidents": 2.82, "Fatalities": 3.19, "Injuries": 8.59, "Hostages": 1.23},
    {"Cluster": "Very High Risk", "Score": 8.03, "Incidents": 2347.67, "Fatalities": 6093.17, "Injuries": 6823.17, "Hostages": 1061.67},
    {"Cluster": "Extreme Risk (Afghanistan)", "Score": 8.96, "Incidents": 4443.00, "Fatalities": 12726.00, "Injuries": 21263.00, "Hostages": 4101.00},
    {"Cluster": "Extreme Risk (Iraq)", "Score": 9.33, "Incidents": 11183.00, "Fatalities": 21286.00, "Injuries": 38381.00, "Hostages": 1771.00},
    {"Cluster": "High Risk", "Score": 5.24, "Incidents": 386.38, "Fatalities": 566.45, "Injuries": 701.90, "Hostages": 130.67}
]

df = pd.DataFrame(data)

# Metrics to plot
metrics = ['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']

# Normalize values to 0-1 scale
df_normalized = df.copy()
for metric in metrics:
    min_val = df[metric].min()
    max_val = df[metric].max()
    df_normalized[metric] = (df[metric] - min_val) / (max_val - min_val)

# Brand colors
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C']

# Create radar chart
fig = go.Figure()

for i, cluster in enumerate(df_normalized['Cluster']):
    values = [df_normalized.iloc[i][metric] for metric in metrics]
    # Close the polygon by adding the first value at the end
    values_closed = values + [values[0]]
    metrics_closed = metrics + [metrics[0]]
    
    fig.add_trace(go.Scatterpolar(
        r=values_closed,
        theta=metrics_closed,
        fill='toself',
        name=cluster,
        line=dict(color=colors[i % len(colors)]),
        fillcolor=colors[i % len(colors)],
        opacity=0.6
    ))

fig.update_layout(
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 1]
        )
    ),
    title="Terrorism Risk Clusters",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Save as PNG and SVG
fig.write_image("radar_chart.png")
fig.write_image("radar_chart.svg", format="svg")

print("Radar chart saved as radar_chart.png and radar_chart.svg")