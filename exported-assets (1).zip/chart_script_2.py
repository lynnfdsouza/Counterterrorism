import plotly.express as px
import pandas as pd

# Create the data with abbreviated names to fit character limits
data = [
    {"Cluster_Name": "Low Risk", "Avg_Score": 0.98, "Count": 113},
    {"Cluster_Name": "High Risk", "Avg_Score": 5.24, "Count": 42},
    {"Cluster_Name": "Very High Risk", "Avg_Score": 8.03, "Count": 6},
    {"Cluster_Name": "Extreme (AFG)", "Avg_Score": 8.96, "Count": 1},
    {"Cluster_Name": "Extreme (IRQ)", "Avg_Score": 9.33, "Count": 1}
]

df = pd.DataFrame(data)

# Sort by score to have consistent ordering
df = df.sort_values('Avg_Score')

# Create horizontal bar chart with green to red gradient
fig = px.bar(df, 
             y='Cluster_Name', 
             x='Avg_Score',
             orientation='h',
             color='Avg_Score',
             color_continuous_scale=['green', 'red'],
             title="GTI Scores by Risk Cluster")

# Update layout
fig.update_layout(
    xaxis_title="GTI Score",
    yaxis_title="Risk Cluster",
    coloraxis_showscale=False  # Hide the color scale
)

# Update traces for better appearance
fig.update_traces(cliponaxis=False)

# Save as PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")