import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.cluster import KMeans
import numpy as np

# Load the data
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

# Remove any rows with missing values in Score or Incidents
df_clean = df.dropna(subset=['Score', 'Incidents'])

# Prepare data for clustering
X = df_clean[['Score', 'Incidents']].values

# Perform K-means clustering with K=5
kmeans = KMeans(n_clusters=5, random_state=42)
cluster_labels = kmeans.fit_predict(X)

# Add cluster labels to dataframe
df_clean = df_clean.copy()
df_clean['Cluster'] = cluster_labels
df_clean['Cluster_Label'] = 'Cluster ' + (df_clean['Cluster'] + 1).astype(str)

# Define colors for the 5 clusters using more contrasting brand colors
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#D2BA4C', '#B4413C']

# Create scatter plot
fig = go.Figure()

for i in range(5):
    cluster_data = df_clean[df_clean['Cluster'] == i]
    fig.add_trace(go.Scatter(
        x=cluster_data['Score'],
        y=cluster_data['Incidents'],
        mode='markers',
        name=f'Cluster {i+1}',
        marker=dict(
            color=colors[i],
            size=9,
            opacity=0.8,
            line=dict(width=0.5, color='white')
        ),
        text=cluster_data['Country'],
        hovertemplate='<b>%{text}</b><br>GTI Score: %{x}<br>Incidents: %{y}<extra></extra>'
    ))

# Update layout with improved styling
fig.update_layout(
    title='GTI Score vs Incidents by Cluster',
    xaxis_title='GTI Score',
    yaxis_title='Incidents',
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.05, 
        xanchor='center', 
        x=0.5,
        font=dict(size=12)
    ),
    font=dict(size=12)
)

# Update y-axis to use log scale and add grid lines
fig.update_yaxes(
    type="log",
    showgrid=True,
    gridwidth=1,
    gridcolor='rgba(128,128,128,0.2)',
    minor=dict(showgrid=True, gridcolor='rgba(128,128,128,0.1)', gridwidth=0.5),
    tickfont=dict(size=11, color='black')
)

# Update x-axis with grid lines
fig.update_xaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='rgba(128,128,128,0.2)',
    minor=dict(showgrid=True, gridcolor='rgba(128,128,128,0.1)', gridwidth=0.5),
    tickfont=dict(size=11, color='black')
)

# Update traces
fig.update_traces(cliponaxis=False)

# Save as PNG and SVG
fig.write_image('chart.png')
fig.write_image('chart.svg', format='svg')

print(f"Chart saved successfully!")
print(f"Number of countries plotted: {len(df_clean)}")
print(f"Clusters distribution:")
for i in range(5):
    count = len(df_clean[df_clean['Cluster'] == i])
    print(f"Cluster {i+1}: {count} countries")