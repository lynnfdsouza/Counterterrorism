import plotly.express as px
import pandas as pd

# Create the data
data = [
    {"Cluster_Name": "Low Risk", "Count": 113},
    {"Cluster_Name": "High Risk", "Count": 42},
    {"Cluster_Name": "Very High Risk", "Count": 6},
    {"Cluster_Name": "Extreme (AFG)", "Count": 1},  # Abbreviated to fit 15 char limit
    {"Cluster_Name": "Extreme (IRQ)", "Count": 1}   # Abbreviated to fit 15 char limit
]

df = pd.DataFrame(data)

# Define colors from green to red for risk levels
colors = ['#2E8B57', '#D2BA4C', '#964325', '#DB4545', '#B4413C']

# Create pie chart
fig = px.pie(df, 
             values='Count', 
             names='Cluster_Name',
             title='Country Risk Distribution',
             color_discrete_sequence=colors)

# Update traces to show percentages and labels inside
fig.update_traces(
    textposition='inside', 
    textinfo='percent+label'
)

# Apply uniform text settings for pie chart
fig.update_layout(uniformtext_minsize=14, uniformtext_mode='hide')

# Save as PNG and SVG
fig.write_image("risk_distribution.png")
fig.write_image("risk_distribution.svg", format="svg")

fig.show()