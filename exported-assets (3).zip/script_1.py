# Chi-Square Test 1: Independence between Region and Risk Category
print("=== CHI-SQUARE TEST 1: REGION vs RISK CATEGORY ===\n")

# Create contingency table
contingency_table = pd.crosstab(df['Region'], df['Risk_Category'])
print("Contingency Table (Region vs Risk Category):")
print(contingency_table)

# Perform chi-square test
chi2_stat, p_value, dof, expected = chi2_contingency(contingency_table)

print(f"\nChi-Square Test Results:")
print(f"Chi-Square Statistic: {chi2_stat:.4f}")
print(f"P-value: {p_value:.6f}")
print(f"Degrees of Freedom: {dof}")
print(f"Critical Value (α=0.05): {chi2.ppf(0.95, dof):.4f}")

# Interpretation
alpha = 0.05
if p_value < alpha:
    print(f"\n✓ SIGNIFICANT: Reject null hypothesis (p < {alpha})")
    print("There IS a significant association between Region and Risk Category")
else:
    print(f"\n✗ NOT SIGNIFICANT: Fail to reject null hypothesis (p >= {alpha})")
    print("There is NO significant association between Region and Risk Category")

print(f"\nExpected Frequencies:")
expected_df = pd.DataFrame(expected, 
                          index=contingency_table.index, 
                          columns=contingency_table.columns)
print(expected_df.round(2))

# Calculate Cramér's V (effect size)
n = contingency_table.sum().sum()
cramers_v = np.sqrt(chi2_stat / (n * (min(contingency_table.shape) - 1)))
print(f"\nCramér's V (Effect Size): {cramers_v:.4f}")
if cramers_v < 0.1:
    effect_size = "Small"
elif cramers_v < 0.3:
    effect_size = "Medium"
else:
    effect_size = "Large"
print(f"Effect Size Interpretation: {effect_size}")