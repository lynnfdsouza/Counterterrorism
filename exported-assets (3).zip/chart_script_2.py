import plotly.graph_objects as go
import pandas as pd

# Create the data
data = [
    {"Category": "No Risk", "Observed": 636, "Expected_Uniform": 298.8},
    {"Category": "Very Low", "Observed": 338, "Expected_Uniform": 298.8},
    {"Category": "Low", "Observed": 310, "Expected_Uniform": 298.8},
    {"Category": "Medium", "Observed": 278, "Expected_Uniform": 298.8},
    {"Category": "High", "Observed": 165, "Expected_Uniform": 298.8},
    {"Category": "Very High", "Observed": 66, "Expected_Uniform": 298.8}
]

df = pd.DataFrame(data)

# Create grouped bar chart
fig = go.Figure()

# Add observed values
fig.add_trace(go.Bar(
    x=df['Category'],
    y=df['Observed'],
    name='Observed',
    marker_color='#1FB8CD'
))

# Add expected values side by side
fig.add_trace(go.Bar(
    x=df['Category'],
    y=df['Expected_Uniform'],
    name='Expected',
    marker_color='#DB4545'
))

# Update layout for grouped bar chart
fig.update_layout(
    title='Risk Category Distribution Test',
    xaxis_title='Risk Category',
    yaxis_title='Frequency',
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update traces for better visualization
fig.update_traces(cliponaxis=False)

# Save as PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

print("Chart saved as chart.png and chart.svg")