import plotly.graph_objects as go
import pandas as pd

# Data from the provided JSON
data = [
    {"Test": "Region vs Risk", "Chi_Square": 1218.13, "Significant": True, "Critical_Value": 55.76},
    {"Test": "Time vs Risk", "Chi_Square": 12.20, "Significant": False, "Critical_Value": 18.31},
    {"Test": "Incidents vs Casualties", "Chi_Square": 2669.84, "Significant": True, "Critical_Value": 16.92},
    {"Test": "Uniform Distribution", "Chi_Square": 628.77, "Significant": True, "Critical_Value": 11.07},
    {"Test": "Realistic Distribution", "Chi_Square": 865.13, "Significant": True, "Critical_Value": 11.07}
]

df = pd.DataFrame(data)

# Abbreviate test names to fit 15 character limit
test_names = [
    "Region vs Risk",
    "Time vs Risk", 
    "Incidents vs C",
    "Uniform Dist",
    "Realistic Dist"
]

# Create colors based on significance
colors = ['#1FB8CD' if sig else '#DB4545' for sig in df['Significant']]

# Create the bar chart
fig = go.Figure()

# Add bars
fig.add_trace(go.Bar(
    x=test_names,
    y=df['Chi_Square'],
    marker_color=colors,
    name="Chi-Square",
    showlegend=False
))

# Add horizontal lines for critical values across each test
for i, critical_val in enumerate(df['Critical_Value']):
    fig.add_shape(
        type="line",
        x0=i-0.45, x1=i+0.45,
        y0=critical_val, y1=critical_val,
        line=dict(color="black", width=3, dash="solid")
    )

# Add a single reference line trace for legend
fig.add_trace(go.Scatter(
    x=[None], y=[None],
    mode='lines',
    line=dict(color='black', width=3),
    name='Critical Value',
    showlegend=True
))

# Add legend for significance levels
fig.add_trace(go.Scatter(
    x=[None], y=[None],
    mode='markers',
    marker=dict(size=15, color='#1FB8CD'),
    name='Significant',
    showlegend=True
))

fig.add_trace(go.Scatter(
    x=[None], y=[None], 
    mode='markers',
    marker=dict(size=15, color='#DB4545'),
    name='Not Significant',
    showlegend=True
))

# Update layout
fig.update_layout(
    title="Chi-Square Test Statistics",
    xaxis_title="Test",
    yaxis_title="Chi-Square Value",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    yaxis=dict(range=[0, max(df['Chi_Square']) * 1.05])  # Reduce empty space
)

# Keep x-axis labels horizontal for better readability
fig.update_xaxes(tickangle=0)
fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image("chi_square_chart.png")
fig.write_image("chi_square_chart.svg", format="svg")