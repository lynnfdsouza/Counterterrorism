# Chi-Square Test 3: High vs Low Incident Countries
print("=== CHI-SQUARE TEST 3: INCIDENT LEVEL vs CASUALTIES ===\n")

# Create incident level categories
df['Incident_Level'] = df['Incidents'].apply(lambda x:
    'No Incidents' if x == 0 else
    'Low (1-10)' if x <= 10 else
    'Medium (11-100)' if x <= 100 else
    'High (100+)' if x > 100 else 'Unknown')

# Create casualty level categories  
df['Casualty_Level'] = (df['Fatalities'] + df['Injuries']).apply(lambda x:
    'No Casualties' if x == 0 else
    'Low (1-50)' if x <= 50 else
    'Medium (51-500)' if x <= 500 else
    'High (500+)' if x > 500 else 'Unknown')

# Create contingency table
incident_casualty_table = pd.crosstab(df['Incident_Level'], df['Casualty_Level'])
print("Contingency Table (Incident Level vs Casualty Level):")
print(incident_casualty_table)

# Perform chi-square test
chi2_stat3, p_value3, dof3, expected3 = chi2_contingency(incident_casualty_table)

print(f"\nChi-Square Test Results:")
print(f"Chi-Square Statistic: {chi2_stat3:.4f}")
print(f"P-value: {p_value3:.6f}")
print(f"Degrees of Freedom: {dof3}")

# Interpretation
if p_value3 < alpha:
    print(f"\n✓ SIGNIFICANT: Reject null hypothesis (p < {alpha})")
    print("There IS a significant association between Incident Level and Casualty Level")
else:
    print(f"\n✗ NOT SIGNIFICANT: Fail to reject null hypothesis (p >= {alpha})")
    print("There is NO significant association between Incident Level and Casualty Level")

# Calculate Cramér's V
n3 = incident_casualty_table.sum().sum()
cramers_v3 = np.sqrt(chi2_stat3 / (n3 * (min(incident_casualty_table.shape) - 1)))
print(f"\nCramér's V (Effect Size): {cramers_v3:.4f}")

# Standardized residuals to identify which cells contribute most to chi-square
print(f"\nStandardized Residuals (>2 indicates significant contribution):")
standardized_residuals = (incident_casualty_table - expected3) / np.sqrt(expected3)
print(standardized_residuals.round(2))