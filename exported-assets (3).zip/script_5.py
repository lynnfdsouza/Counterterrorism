# Summary and export results
print("=== CHI-SQUARE TEST SUMMARY ===\n")

# Create comprehensive results summary
chi_square_results = {
    'Test_1_Region_vs_Risk': {
        'Chi_Square': chi2_stat,
        'P_Value': p_value,
        'DOF': dof,
        'Cramers_V': cramers_v,
        'Significant': p_value < alpha,
        'Effect_Size': 'Large' if cramers_v >= 0.3 else ('Medium' if cramers_v >= 0.1 else 'Small')
    },
    'Test_2_Time_vs_Risk': {
        'Chi_Square': chi2_stat2,
        'P_Value': p_value2,
        'DOF': dof2,
        'Cramers_V': cramers_v2,
        'Significant': p_value2 < alpha,
        'Effect_Size': 'Large' if cramers_v2 >= 0.3 else ('Medium' if cramers_v2 >= 0.1 else 'Small')
    },
    'Test_3_Incidents_vs_Casualties': {
        'Chi_Square': chi2_stat3,
        'P_Value': p_value3,
        'DOF': dof3,
        'Cramers_V': cramers_v3,
        'Significant': p_value3 < alpha,
        'Effect_Size': 'Large' if cramers_v3 >= 0.3 else ('Medium' if cramers_v3 >= 0.1 else 'Small')
    },
    'Goodness_of_Fit_Uniform': {
        'Chi_Square': chi2_gof,
        'P_Value': p_value_gof,
        'DOF': n_categories - 1,
        'Significant': p_value_gof < alpha
    },
    'Goodness_of_Fit_Realistic': {
        'Chi_Square': chi2_real,
        'P_Value': p_value_real,
        'DOF': n_categories - 1,
        'Significant': p_value_real < alpha
    }
}

print("SUMMARY OF ALL CHI-SQUARE TESTS:")
print("=" * 60)

for test_name, results in chi_square_results.items():
    print(f"\n{test_name.replace('_', ' ').upper()}:")
    print(f"  Chi-Square Statistic: {results['Chi_Square']:.4f}")
    print(f"  P-value: {results['P_Value']:.6f}")
    print(f"  Degrees of Freedom: {results['DOF']}")
    
    if 'Cramers_V' in results:
        print(f"  Cramér's V: {results['Cramers_V']:.4f} ({results['Effect_Size']} effect)")
    
    significance = "SIGNIFICANT" if results['Significant'] else "NOT SIGNIFICANT"
    print(f"  Result: {significance}")

# Create results dataframe for export
results_df = pd.DataFrame([
    ['Region vs Risk Category', chi2_stat, p_value, dof, cramers_v, p_value < alpha],
    ['Time Period vs Risk Category', chi2_stat2, p_value2, dof2, cramers_v2, p_value2 < alpha],
    ['Incidents vs Casualties', chi2_stat3, p_value3, dof3, cramers_v3, p_value3 < alpha],
    ['Uniform Distribution Test', chi2_gof, p_value_gof, n_categories-1, np.nan, p_value_gof < alpha],
    ['Realistic Distribution Test', chi2_real, p_value_real, n_categories-1, np.nan, p_value_real < alpha]
], columns=['Test_Name', 'Chi_Square_Stat', 'P_Value', 'DOF', 'Cramers_V', 'Significant'])

results_df.to_csv('Chi_Square_Test_Results.csv', index=False)

# Export contingency tables
contingency_table.to_csv('Contingency_Table_Region_Risk.csv')
time_risk_table.to_csv('Contingency_Table_Time_Risk.csv')
incident_casualty_table.to_csv('Contingency_Table_Incidents_Casualties.csv')

print(f"\n\nDATA EXPORTED:")
print("- Chi_Square_Test_Results.csv")
print("- Contingency_Table_Region_Risk.csv")
print("- Contingency_Table_Time_Risk.csv") 
print("- Contingency_Table_Incidents_Casualties.csv")

print(f"\n=== KEY FINDINGS ===")
print("✓ Strong association between Region and Risk Category")
print("✗ No significant temporal trends in risk categories")
print("✓ Very strong association between incident levels and casualties")
print("✓ Risk categories deviate significantly from uniform distribution")
print("✓ Current distribution differs from expected realistic security patterns")