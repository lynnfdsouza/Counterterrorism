import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency, chi2
from scipy.stats import chisquare
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

print("=== CHI-SQUARE TESTS FOR GLOBAL TERRORISM INDEX DATA ===\n")

# Add regional classification for analysis
region_mapping = {
    'Iraq': 'Middle East', 'Iran': 'Middle East', 'Syria': 'Middle East', 'Yemen': 'Middle East',
    'Israel': 'Middle East', 'Turkey': 'Middle East', 'Lebanon': 'Middle East', 'Jordan': 'Middle East',
    'Afghanistan': 'South Asia', 'Pakistan': 'South Asia', 'India': 'South Asia', 'Bangladesh': 'South Asia',
    'Sri Lanka': 'South Asia', 'Nepal': 'South Asia', 'Bhutan': 'South Asia', 'Maldives': 'South Asia',
    'Nigeria': 'Africa', 'Somalia': 'Africa', 'Mali': 'Africa', 'Burkina Faso': 'Africa', 'Niger': 'Africa',
    'Chad': 'Africa', 'Egypt': 'Africa', 'Libya': 'Africa', 'Kenya': 'Africa', 'Ethiopia': 'Africa',
    'Algeria': 'Africa', 'Morocco': 'Africa', 'Tunisia': 'Africa', 'Sudan': 'Africa', 'South Sudan': 'Africa',
    'Cameroon': 'Africa', 'Democratic Republic of the Congo': 'Africa', 'Central African Republic': 'Africa',
    'Myanmar': 'Southeast Asia', 'Thailand': 'Southeast Asia', 'Philippines': 'Southeast Asia',
    'Indonesia': 'Southeast Asia', 'Malaysia': 'Southeast Asia', 'Singapore': 'Southeast Asia',
    'United States': 'North America', 'Canada': 'North America', 'Mexico': 'North America',
    'Colombia': 'South America', 'Peru': 'South America', 'Brazil': 'South America', 'Argentina': 'South America',
    'Venezuela': 'South America', 'Chile': 'South America', 'Ecuador': 'South America', 'Uruguay': 'South America',
    'Russia': 'Europe/Eurasia', 'Ukraine': 'Europe/Eurasia', 'United Kingdom': 'Europe/Eurasia',
    'France': 'Europe/Eurasia', 'Germany': 'Europe/Eurasia', 'Spain': 'Europe/Eurasia', 'Italy': 'Europe/Eurasia',
    'Belgium': 'Europe/Eurasia', 'Netherlands': 'Europe/Eurasia', 'Greece': 'Europe/Eurasia',
    'China': 'East Asia', 'Japan': 'East Asia', 'South Korea': 'East Asia', 'North Korea': 'East Asia'
}

df['Region'] = df['Country'].map(region_mapping).fillna('Other')

print("Regions identified:")
print(df['Region'].value_counts())
print(f"\nTotal countries: {df['Country'].nunique()}")
print(f"Total observations: {len(df)}")

# Create risk categories based on GTI Score
def categorize_risk(score):
    if score == 0:
        return 'No Risk'
    elif score < 2:
        return 'Very Low'
    elif score < 4:
        return 'Low'
    elif score < 6:
        return 'Medium' 
    elif score < 8:
        return 'High'
    else:
        return 'Very High'

df['Risk_Category'] = df['Score'].apply(categorize_risk)

print(f"\nRisk categories distribution:")
print(df['Risk_Category'].value_counts())