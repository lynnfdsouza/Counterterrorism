import pandas as pd
import plotly.graph_objects as go
import numpy as np

# Load the data
data = [
    {"Region": "Africa", "High": 71, "Low": 29, "Medium": 54, "No Risk": 10, "Very High": 24, "Very Low": 10},
    {"Region": "East Asia", "High": 3, "Low": 3, "Medium": 5, "No Risk": 20, "Very High": 0, "Very Low": 13},
    {"Region": "Europe/Eurasia", "High": 9, "Low": 42, "Medium": 47, "No Risk": 5, "Very High": 0, "Very Low": 7},
    {"Region": "Middle East", "High": 23, "Low": 8, "Medium": 33, "No Risk": 0, "Very High": 22, "Very Low": 2},
    {"Region": "North America", "High": 0, "Low": 14, "Medium": 4, "No Risk": 0, "Very High": 0, "Very Low": 4},
    {"Region": "Other", "High": 8, "Low": 175, "Medium": 76, "No Risk": 578, "Very High": 0, "Very Low": 263},
    {"Region": "South America", "High": 13, "Low": 26, "Medium": 16, "No Risk": 3, "Very High": 0, "Very Low": 30},
    {"Region": "South Asia", "High": 15, "Low": 5, "Medium": 22, "No Risk": 9, "Very High": 20, "Very Low": 6},
    {"Region": "Southeast Asia", "High": 23, "Low": 8, "Medium": 21, "No Risk": 11, "Very High": 0, "Very Low": 3}
]

# Convert to DataFrame
df = pd.DataFrame(data)

# Set Region as index
df.set_index('Region', inplace=True)

# Calculate row totals
df['Total'] = df.sum(axis=1)

# Calculate column totals
col_totals = df.sum(axis=0)
col_totals.name = 'Total'

# Add column totals as a new row
df_with_totals = pd.concat([df, col_totals.to_frame().T])

# Prepare data for heatmap (exclude totals for the main heatmap visualization)
heatmap_data = df.iloc[:, :-1]  # Exclude the 'Total' column for main heatmap

# Create the heatmap
fig = go.Figure(data=go.Heatmap(
    z=heatmap_data.values,
    x=heatmap_data.columns,
    y=heatmap_data.index,
    colorscale='Blues',
    showscale=True,
    hovertemplate='Region: %{y}<br>Risk: %{x}<br>Count: %{z}<extra></extra>'
))

# Update layout
fig.update_layout(
    title='Region vs Risk Category Heatmap',
    xaxis_title='Risk Category',
    yaxis_title='Region'
)

# Update axes
fig.update_xaxes(side="bottom")
fig.update_yaxes(autorange="reversed")  # To match typical contingency table layout

# Save as PNG and SVG
fig.write_image("heatmap.png")
fig.write_image("heatmap.svg", format="svg")

# Display the contingency table with totals for reference
print("Contingency Table with Totals:")
print(df_with_totals)