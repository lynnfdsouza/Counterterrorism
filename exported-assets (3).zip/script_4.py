# Chi-Square Goodness of Fit Test
print("=== CHI-SQUARE GOODNESS OF FIT TEST ===\n")

# Test if risk categories follow a uniform distribution
observed_risk = df['Risk_Category'].value_counts().sort_index()
print("Observed Risk Category Frequencies:")
print(observed_risk)

# Expected frequencies for uniform distribution
n_categories = len(observed_risk)
total_obs = observed_risk.sum()
expected_uniform = [total_obs / n_categories] * n_categories

print(f"\nExpected frequencies (uniform distribution): {expected_uniform[0]:.2f} each")

# Perform goodness of fit test
chi2_gof, p_value_gof = chisquare(observed_risk.values, expected_uniform)

print(f"\nGoodness of Fit Test Results:")
print(f"Chi-Square Statistic: {chi2_gof:.4f}")
print(f"P-value: {p_value_gof:.6f}")
print(f"Degrees of Freedom: {n_categories - 1}")

if p_value_gof < alpha:
    print(f"\n✓ SIGNIFICANT: Reject null hypothesis (p < {alpha})")
    print("Risk categories do NOT follow a uniform distribution")
else:
    print(f"\n✗ NOT SIGNIFICANT: Fail to reject null hypothesis (p >= {alpha})")
    print("Risk categories MAY follow a uniform distribution")

# Additional analysis: Test against expected terrorism distribution
# Based on global security research, we might expect more countries in low-risk categories
expected_realistic = [
    total_obs * 0.05,  # High: 5%
    total_obs * 0.20,  # Low: 20%  
    total_obs * 0.18,  # Medium: 18%
    total_obs * 0.50,  # No Risk: 50%
    total_obs * 0.02,  # Very High: 2%
    total_obs * 0.05   # Very Low: 5%
]

print(f"\n=== REALISTIC DISTRIBUTION TEST ===")
print("Expected frequencies (realistic security distribution):")
for i, category in enumerate(observed_risk.index):
    print(f"{category}: {expected_realistic[i]:.1f}")

chi2_real, p_value_real = chisquare(observed_risk.values, expected_realistic)
print(f"\nChi-Square Statistic: {chi2_real:.4f}")
print(f"P-value: {p_value_real:.6f}")

if p_value_real < alpha:
    print(f"\n✓ SIGNIFICANT: Reject null hypothesis (p < {alpha})")
    print("Risk categories do NOT follow the expected realistic distribution")
else:
    print(f"\n✗ NOT SIGNIFICANT: Fail to reject null hypothesis (p >= {alpha})")
    print("Risk categories MAY follow the expected realistic distribution")