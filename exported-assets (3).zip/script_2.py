# Chi-Square Test 2: Time Period vs Risk Category
print("=== CHI-SQUARE TEST 2: TIME PERIOD vs RISK CATEGORY ===\n")

# Create time periods
df['Time_Period'] = df['Year'].apply(lambda x: 
    'Early (2012-2014)' if x <= 2014 else
    'Middle (2015-2018)' if x <= 2018 else
    'Recent (2019-2022)')

# Create contingency table
time_risk_table = pd.crosstab(df['Time_Period'], df['Risk_Category'])
print("Contingency Table (Time Period vs Risk Category):")
print(time_risk_table)

# Perform chi-square test
chi2_stat2, p_value2, dof2, expected2 = chi2_contingency(time_risk_table)

print(f"\nChi-Square Test Results:")
print(f"Chi-Square Statistic: {chi2_stat2:.4f}")
print(f"P-value: {p_value2:.6f}")
print(f"Degrees of Freedom: {dof2}")
print(f"Critical Value (α=0.05): {chi2.ppf(0.95, dof2):.4f}")

# Interpretation
if p_value2 < alpha:
    print(f"\n✓ SIGNIFICANT: Reject null hypothesis (p < {alpha})")
    print("There IS a significant association between Time Period and Risk Category")
else:
    print(f"\n✗ NOT SIGNIFICANT: Fail to reject null hypothesis (p >= {alpha})")
    print("There is NO significant association between Time Period and Risk Category")

# Calculate Cramér's V for time period
n2 = time_risk_table.sum().sum()
cramers_v2 = np.sqrt(chi2_stat2 / (n2 * (min(time_risk_table.shape) - 1)))
print(f"\nCramér's V (Effect Size): {cramers_v2:.4f}")

print(f"\nExpected Frequencies:")
expected_df2 = pd.DataFrame(expected2, 
                           index=time_risk_table.index, 
                           columns=time_risk_table.columns)
print(expected_df2.round(2))