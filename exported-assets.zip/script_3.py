# Additional analysis - zero terrorism countries and distribution
zero_terrorism = df[df['Score'] == 0].groupby('Year')['Country'].count()
print("Countries with Zero GTI Score by Year:")
print(zero_terrorism)

# Score distribution analysis
score_ranges = pd.cut(df['Score'], bins=[0, 1, 3, 5, 7, 10], labels=['Very Low (0-1)', 'Low (1-3)', 'Medium (3-5)', 'High (5-7)', 'Very High (7-10)'])
score_distribution = score_ranges.value_counts().sort_index()
print("\nGTI Score Distribution:")
print(score_distribution)

# Incident-to-fatality ratio analysis
df['Fatality_Rate'] = df['Fatalities'] / (df['Incidents'] + 0.001)  # Avoid division by zero
df['Injury_Rate'] = df['Injuries'] / (df['Incidents'] + 0.001)

print("\nCountries with Highest Fatality Rate per Incident (min 10 incidents):")
high_fatality_rate = df[df['Incidents'] >= 10].groupby('Country')['Fatality_Rate'].mean().sort_values(ascending=False).head(10)
print(high_fatality_rate.round(3))

# Export processed data for visualization
df_summary = df.groupby(['Country', 'iso3c']).agg({
    'Score': 'mean',
    'Incidents': 'sum',
    'Fatalities': 'sum',
    'Injuries': 'sum',
    'Hostages': 'sum',
    'Region': 'first'
}).reset_index()

df_summary.to_csv('GTI_Country_Summary.csv', index=False)
print("\nCountry summary data exported to 'GTI_Country_Summary.csv'")

# Yearly trends for top 5 countries
yearly_trends = df[df['Country'].isin(['Iraq', 'Afghanistan', 'Pakistan', 'Nigeria', 'Somalia'])].pivot(index='Year', columns='Country', values='Score')
yearly_trends.to_csv('GTI_Yearly_Trends_Top5.csv')
print("Yearly trends for top 5 countries exported to 'GTI_Yearly_Trends_Top5.csv'")