import plotly.express as px
import pandas as pd

# Create the data
data = [
    {"Category": "Very Low (0-1)", "Count": 163},
    {"Category": "Low (1-3)", "Count": 324},
    {"Category": "Medium (3-5)", "Count": 321},
    {"Category": "High (5-7)", "Count": 198},
    {"Category": "Very High (7-10)", "Count": 151}
]

df = pd.DataFrame(data)

# Create abbreviated categories for display (within 15 char limit)
df['Display_Cat'] = ['Very Low', 'Low', 'Medium', 'High', 'Very High']

# Create donut chart
fig = px.pie(df, 
             values='Count', 
             names='Display_Cat',
             title='Countries by GTI Score Range',
             hole=0.4,  # Creates the donut effect
             color_discrete_sequence=['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C'])

# Update traces to show percentages
fig.update_traces(textposition='inside', 
                  textinfo='percent+label')

# Apply uniform text settings for pie chart
fig.update_layout(uniformtext_minsize=14, uniformtext_mode='hide')

# Save as PNG and SVG
fig.write_image("donut_chart.png")
fig.write_image("donut_chart.svg", format="svg")

fig.show()