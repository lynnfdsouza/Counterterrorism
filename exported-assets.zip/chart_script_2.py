import plotly.graph_objects as go
import pandas as pd

# Data provided
data = [
  {"Region": "South Asia", "Incidents": 10787, "Fatalities": 22569, "Injuries": 38715},
  {"Region": "Middle East", "Incidents": 15108, "Fatalities": 31796, "Injuries": 53961},
  {"Region": "Africa", "Incidents": 10153, "Fatalities": 31080, "Injuries": 24148},
  {"Region": "Southeast Asia", "Incidents": 3741, "Fatalities": 2603, "Injuries": 5227},
  {"Region": "Europe/Eurasia", "Incidents": 1277, "Fatalities": 806, "Injuries": 2110},
  {"Region": "South America", "Incidents": 1761, "Fatalities": 1180, "Injuries": 2418},
  {"Region": "North America", "Incidents": 56, "Fatalities": 34, "Injuries": 59},
  {"Region": "Other", "Incidents": 4990, "Fatalities": 5925, "Injuries": 7100}
]

df = pd.DataFrame(data)

# Create the stacked bar chart
fig = go.Figure()

# Add each metric as a separate trace
fig.add_trace(go.Bar(
    name='Incidents',
    x=df['Region'],
    y=df['Incidents'],
    marker_color='#1FB8CD',  # Strong cyan
    hovertemplate='<b>%{x}</b><br>Incidents: %{y}<extra></extra>'
))

fig.add_trace(go.Bar(
    name='Fatalities', 
    x=df['Region'],
    y=df['Fatalities'],
    marker_color='#DB4545',  # Bright red
    hovertemplate='<b>%{x}</b><br>Fatalities: %{y}<extra></extra>'
))

fig.add_trace(go.Bar(
    name='Injuries',
    x=df['Region'],
    y=df['Injuries'],
    marker_color='#2E8B57',  # Sea green
    hovertemplate='<b>%{x}</b><br>Injuries: %{y}<extra></extra>'
))

# Update layout for stacked bars
fig.update_layout(
    barmode='stack',
    title='Regional Terror Analysis',
    xaxis_title='Region',
    yaxis_title='Count',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Format y-axis to show abbreviated numbers
fig.update_yaxes(tickformat='.0s')

# Apply formatting guidelines
fig.update_traces(cliponaxis=False)

# Rotate x-axis labels for better readability
fig.update_xaxes(tickangle=45)

# Save the chart
fig.write_image('chart.png')
fig.write_image('chart.svg', format='svg')