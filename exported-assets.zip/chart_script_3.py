import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

# Data provided
data = [
    {"Country": "Iraq", "Fatalities": 21286},
    {"Country": "Afghanistan", "Fatalities": 12726},
    {"Country": "Nigeria", "Fatalities": 10191},
    {"Country": "Pakistan", "Fatalities": 7692},
    {"Country": "Somalia", "Fatalities": 7209},
    {"Country": "Syria", "Fatalities": 5977},
    {"Country": "Burkina Faso", "Fatalities": 3515},
    {"Country": "Mali", "Fatalities": 3428},
    {"Country": "Yemen", "Fatalities": 2547},
    {"Country": "Egypt", "Fatalities": 2494},
    {"Country": "Myanmar", "Fatalities": 2375},
    {"Country": "Democratic Republic of the Congo", "Fatalities": 1854},
    {"Country": "Niger", "Fatalities": 1686},
    {"Country": "India", "Fatalities": 1649},
    {"Country": "Philippines", "Fatalities": 1618}
]

df = pd.DataFrame(data)

# Abbreviate country names to fit 15 character limit
df['Country_Short'] = df['Country'].replace({
    'Democratic Republic of the Congo': 'DR Congo',
    'Afghanistan': 'Afghanistan',
    'Burkina Faso': 'Burkina Faso',
    'Philippines': 'Philippines'
})

# Create red gradient colors
import numpy as np
n_countries = len(df)
# Create gradient from light red to dark red
colors = []
for i in range(n_countries):
    intensity = 0.3 + (0.7 * i / (n_countries - 1))  # From 0.3 to 1.0
    color = f'rgba(219, 69, 69, {intensity})'  # Using brand red #DB4545
    colors.append(color)

# Reverse to have darkest red for highest values
colors.reverse()

# Create horizontal bar chart
fig = go.Figure(data=[
    go.Bar(
        y=df['Country_Short'],
        x=df['Fatalities'],
        orientation='h',
        marker=dict(color=colors),
        text=[f'{val/1000:.1f}k' for val in df['Fatalities']],
        textposition='outside',
        hovertemplate='<b>%{y}</b><br>Fatalities: %{text}<extra></extra>'
    )
])

# Update layout
fig.update_layout(
    title='Top 15 Countries by Fatalities 2012-22',
    xaxis_title='Fatalities (k)',
    yaxis_title='Country'
)

# Update x-axis to show values in thousands
fig.update_xaxes(
    tickmode='array',
    tickvals=[0, 5000, 10000, 15000, 20000],
    ticktext=['0', '5k', '10k', '15k', '20k']
)

# Reverse y-axis order to show highest values at top
fig.update_yaxes(categoryorder='array', categoryarray=df['Country_Short'].tolist())

# Apply cliponaxis
fig.update_traces(cliponaxis=False)

# Save as both PNG and SVG
fig.write_image('chart.png')
fig.write_image('chart.svg', format='svg')

print("Chart saved as chart.png and chart.svg")