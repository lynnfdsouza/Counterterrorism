# Analyze temporal trends
yearly_stats = df.groupby('Year').agg({
    'Score': ['mean', 'max', 'min'],
    'Incidents': 'sum',
    'Fatalities': 'sum',
    'Injuries': 'sum',
    'Hostages': 'sum'
}).round(2)

print("Yearly Aggregated Statistics:")
print(yearly_stats)

# Top 10 countries by average GTI score across all years
top_countries = df.groupby('Country')['Score'].mean().sort_values(ascending=False).head(10)
print("\nTop 10 Countries by Average GTI Score:")
print(top_countries)

# Countries with most incidents over time
incident_countries = df.groupby('Country')['Incidents'].sum().sort_values(ascending=False).head(10)
print("\nTop 10 Countries by Total Incidents:")
print(incident_countries)

# Most deadly countries (total fatalities)
fatality_countries = df.groupby('Country')['Fatalities'].sum().sort_values(ascending=False).head(10)
print("\nTop 10 Countries by Total Fatalities:")
print(fatality_countries)