import pandas as pd
import numpy as np
import plotly.graph_objects as go

# Create the correlation data from the provided JSON
data = [
  {"Variable1": "Score", "Variable2": "Score", "Correlation": 1.000},
  {"Variable1": "Score", "Variable2": "Incidents", "Correlation": 0.517},
  {"Variable1": "Score", "Variable2": "Fatalities", "Correlation": 0.479},
  {"Variable1": "Score", "Variable2": "Injuries", "Correlation": 0.411},
  {"Variable1": "Score", "Variable2": "Hostages", "Correlation": 0.263},
  {"Variable1": "Incidents", "Variable2": "Score", "Correlation": 0.517},
  {"Variable1": "Incidents", "Variable2": "Incidents", "Correlation": 1.000},
  {"Variable1": "Incidents", "Variable2": "Fatalities", "Correlation": 0.860},
  {"Variable1": "Incidents", "Variable2": "Injuries", "Correlation": 0.863},
  {"Variable1": "Incidents", "Variable2": "Hostages", "Correlation": 0.282},
  {"Variable1": "Fatalities", "Variable2": "Score", "Correlation": 0.479},
  {"Variable1": "Fatalities", "Variable2": "Incidents", "Correlation": 0.860},
  {"Variable1": "Fatalities", "Variable2": "Fatalities", "Correlation": 1.000},
  {"Variable1": "Fatalities", "Variable2": "Injuries", "Correlation": 0.913},
  {"Variable1": "Fatalities", "Variable2": "Hostages", "Correlation": 0.318},
  {"Variable1": "Injuries", "Variable2": "Score", "Correlation": 0.411},
  {"Variable1": "Injuries", "Variable2": "Incidents", "Correlation": 0.863},
  {"Variable1": "Injuries", "Variable2": "Fatalities", "Correlation": 0.913},
  {"Variable1": "Injuries", "Variable2": "Injuries", "Correlation": 1.000},
  {"Variable1": "Injuries", "Variable2": "Hostages", "Correlation": 0.317},
  {"Variable1": "Hostages", "Variable2": "Score", "Correlation": 0.263},
  {"Variable1": "Hostages", "Variable2": "Incidents", "Correlation": 0.282},
  {"Variable1": "Hostages", "Variable2": "Fatalities", "Correlation": 0.318},
  {"Variable1": "Hostages", "Variable2": "Injuries", "Correlation": 0.317},
  {"Variable1": "Hostages", "Variable2": "Hostages", "Correlation": 1.000}
]

# Convert to DataFrame and pivot to create correlation matrix
df = pd.DataFrame(data)
correlation_matrix = df.pivot(index='Variable1', columns='Variable2', values='Correlation')

# Ensure the order of variables is consistent
variables = ['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']
correlation_matrix = correlation_matrix.reindex(index=variables, columns=variables)

# Create the heatmap
fig = go.Figure(data=go.Heatmap(
    z=correlation_matrix.values,
    x=correlation_matrix.columns,
    y=correlation_matrix.index,
    colorscale='RdYlBu_r',
    zmid=0,
    zmin=-1,
    zmax=1,
    text=correlation_matrix.values.round(3),
    texttemplate="%{text}",
    textfont={"size": 12},
    hoverongaps=False,
    colorbar=dict(title="Correlation")
))

fig.update_layout(
    title="GTI Correlation Matrix",
    xaxis_title="Variables",
    yaxis_title="Variables"
)

# Save as PNG and SVG
fig.write_image("correlation_heatmap.png")
fig.write_image("correlation_heatmap.svg", format="svg")