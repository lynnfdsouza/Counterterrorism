import pandas as pd
import plotly.express as px
import plotly.io as pio
import numpy as np

# Load the Overall Scores sheet which has all years data
df = pd.read_excel("Global-Terrorism-Index-2023.xlsx", sheet_name="Overall Scores")

# Get score columns (2012 Score through 2022 Score)
score_columns = [col for col in df.columns if 'Score' in col and col != 'Country']

# Calculate average GTI score across all years for each country
df_avg = df.copy()
df_avg['Avg_Score'] = df[score_columns].mean(axis=1, skipna=True)

# Prepare data for choropleth map
map_data = df_avg[['Country', 'Iso3c', 'Avg_Score']].copy()
map_data = map_data.rename(columns={'Iso3c': 'iso3c', 'Avg_Score': 'GTI Score'})

# Create choropleth world map
fig = px.choropleth(
    map_data,
    locations='iso3c',
    color='GTI Score',
    hover_name='Country',
    hover_data={'iso3c': False, 'GTI Score': ':.2f'},
    color_continuous_scale=['#FFFF99', '#FF4500', '#8B0000'],  # Light yellow to dark red
    title='Avg GTI Score by Country'
)

# Update layout
fig.update_layout(
    coloraxis_colorbar=dict(
        title="GTI Score",
        tickmode='linear',
        tick0=0,
        dtick=2
    )
)

# Save as both PNG and SVG
fig.write_image("gti_choropleth.png")
fig.write_image("gti_choropleth.svg", format="svg")

print("Chart saved successfully!")
print(f"Data shape: {map_data.shape}")
print(f"GTI Score range: {map_data['GTI Score'].min():.2f} - {map_data['GTI Score'].max():.2f}")