import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Load the Combined raw sheet which has all yearly data
df = pd.read_excel("Global-Terrorism-Index-2023.xlsx", sheet_name="Combined raw")

# Check unique countries to see exact names
print("Sample of countries in the data:")
print(sorted(df['Country'].unique())[:20])

# Check years available
print(f"\nYears available: {sorted(df['Year'].unique())}")

# Filter for the top 5 countries and years 2012-2022
top5_countries = ['Iraq', 'Afghanistan', 'Pakistan', 'Nigeria', 'Somalia']
filtered_df = df[
    (df['Country'].isin(top5_countries)) & 
    (df['Year'] >= 2012) & 
    (df['Year'] <= 2022)
].copy()

print(f"\nFiltered data shape: {filtered_df.shape}")
print(f"Countries found: {filtered_df['Country'].unique()}")
print(f"Years found: {sorted(filtered_df['Year'].unique())}")

# Create the line chart
fig = px.line(
    filtered_df, 
    x='Year', 
    y='Score', 
    color='Country',
    markers=True,
    title='GTI Scores: Top 5 Countries 2012-2022'
)

# Update traces to show markers
fig.update_traces(cliponaxis=False, marker=dict(size=6))

# Update layout with legend centered under title (5 items)
fig.update_layout(
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.05, 
        xanchor='center', 
        x=0.5
    ),
    xaxis_title='Year',
    yaxis_title='GTI Score'
)

# Save as both PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

print("\nChart saved successfully!")