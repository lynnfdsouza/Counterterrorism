import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Load and examine the dataset
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

# Basic dataset information
print("Dataset Shape:", df.shape)
print("\nColumn Information:")
print(df.info())
print("\nDataset Overview:")
print(df.head(10))
print("\nBasic Statistics:")
print(df.describe())

# Check for missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Unique years in dataset
print("\nYears covered:", sorted(df['Year'].unique()))
print("Total countries:", df['Country'].nunique())