# Regional analysis - let's create regional groupings based on common knowledge
region_mapping = {
    'Iraq': 'Middle East', 'Iran': 'Middle East', 'Syria': 'Middle East', 'Yemen': 'Middle East',
    'Israel': 'Middle East', 'Turkey': 'Middle East', 'Lebanon': 'Middle East',
    'Afghanistan': 'South Asia', 'Pakistan': 'South Asia', 'India': 'South Asia', 'Bangladesh': 'South Asia',
    'Nigeria': 'Africa', 'Somalia': 'Africa', 'Mali': 'Africa', 'Burkina Faso': 'Africa', 'Niger': 'Africa',
    'Chad': 'Africa', 'Egypt': 'Africa', 'Libya': 'Africa', 'Kenya': 'Africa', 'Ethiopia': 'Africa',
    'Myanmar': 'Southeast Asia', 'Thailand': 'Southeast Asia', 'Philippines': 'Southeast Asia',
    'United States': 'North America', 'Canada': 'North America', 'Mexico': 'North America',
    'Colombia': 'South America', 'Peru': 'South America', 'Brazil': 'South America',
    'Russia': 'Europe/Eurasia', 'Ukraine': 'Europe/Eurasia', 'United Kingdom': 'Europe/Eurasia',
    'France': 'Europe/Eurasia', 'Germany': 'Europe/Eurasia', 'Spain': 'Europe/Eurasia'
}

# Add more countries to regions based on the data
df['Region'] = df['Country'].map(region_mapping).fillna('Other')

# Regional analysis
regional_stats = df.groupby('Region').agg({
    'Score': 'mean',
    'Incidents': 'sum',
    'Fatalities': 'sum',
    'Injuries': 'sum'
}).round(2).sort_values('Score', ascending=False)

print("Regional Analysis (Average GTI Score and Total Casualties):")
print(regional_stats)

# Correlation analysis
correlation_matrix = df[['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']].corr()
print("\nCorrelation Matrix:")
print(correlation_matrix.round(3))

# Most improved/deteriorated countries (2012 vs 2022)
df_2012 = df[df['Year'] == 2012].set_index('Country')['Score']
df_2022 = df[df['Year'] == 2022].set_index('Country')['Score']
change = (df_2022 - df_2012).dropna().sort_values()

print("\nMost Improved Countries (2012-2022):")
print(change.head(10))
print("\nMost Deteriorated Countries (2012-2022):")
print(change.tail(10))