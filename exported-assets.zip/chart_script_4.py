import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

# Load the 2022 data which has the most recent incidents and fatalities
df_2022 = pd.read_excel('Global-Terrorism-Index-2023.xlsx', sheet_name='2022')

# Clean the data - remove any rows with missing values
df_2022 = df_2022.dropna(subset=['Incidents', 'Fatalities', 'Country'])

# Create a combined metric to identify top 10 most affected countries
# Using a weighted combination of incidents and fatalities
df_2022['Combined_Impact'] = df_2022['Incidents'] + (df_2022['Fatalities'] * 2)  # Weight fatalities more heavily
df_2022_sorted = df_2022.sort_values('Combined_Impact', ascending=False)

# Get top 10 most affected countries
top_10 = df_2022_sorted.head(10)

print("Top 10 most affected countries:")
print(top_10[['Country', 'Incidents', 'Fatalities', 'Combined_Impact']])

# Create a simple region mapping based on country names/patterns
def assign_region(country):
    # This is a simplified regional classification
    africa = ['Afghanistan', 'Burkina Faso', 'Somalia', 'Mali', 'Nigeria', 'Chad', 'Niger', 'Cameroon', 'DRC', 'CAR', 'Kenya', 'Ethiopia', 'Egypt', 'Libya', 'Algeria', 'Tunisia', 'Morocco', 'South Africa']
    middle_east = ['Syria', 'Iraq', 'Yemen', 'Turkey', 'Iran', 'Israel', 'Palestine', 'Lebanon', 'Jordan', 'Saudi Arabia']
    asia = ['Pakistan', 'India', 'Philippines', 'Myanmar', 'Thailand', 'Bangladesh', 'Indonesia', 'China', 'Japan']
    europe = ['Russia', 'Ukraine', 'France', 'Germany', 'United Kingdom', 'Spain', 'Italy', 'Greece']
    americas = ['Colombia', 'Peru', 'Mexico', 'Brazil', 'United States', 'Canada', 'Argentina', 'Chile']
    
    if any(region_country in country for region_country in africa):
        return 'Africa'
    elif any(region_country in country for region_country in middle_east):
        return 'Middle East'
    elif any(region_country in country for region_country in asia):
        return 'Asia'
    elif any(region_country in country for region_country in europe):
        return 'Europe'
    elif any(region_country in country for region_country in americas):
        return 'Americas'
    else:
        return 'Other'

# Apply region mapping
df_2022['Region'] = df_2022['Country'].apply(assign_region)

# Create scatter plot
fig = px.scatter(df_2022, 
                x='Incidents', 
                y='Fatalities',
                color='Region',
                title='Terror Incidents vs Fatalities 2022',
                labels={'Incidents': 'Total Incidents', 'Fatalities': 'Total Deaths'},
                hover_data=['Country'])

# Add country labels for top 10 most affected countries
for _, row in top_10.iterrows():
    fig.add_annotation(
        x=row['Incidents'],
        y=row['Fatalities'],
        text=row['Country'][:15],  # Limit to 15 characters as per instructions
        showarrow=True,
        arrowhead=2,
        arrowsize=1,
        arrowwidth=1,
        arrowcolor="black",
        font=dict(size=10),
        bgcolor="white",
        bordercolor="black",
        borderwidth=1
    )

# Update layout
fig.update_traces(cliponaxis=False)

# Update legend to be horizontal and centered if 5 or fewer items
region_count = df_2022['Region'].nunique()
if region_count <= 5:
    fig.update_layout(legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5))

# Save as both PNG and SVG
fig.write_image("scatter_plot.png")
fig.write_image("scatter_plot.svg", format="svg")

fig.show()