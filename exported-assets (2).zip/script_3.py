# ARIMA model identification using ACF and PACF
print("=== ARIMA MODEL IDENTIFICATION ===\n")

# Calculate ACF and PACF for differenced series
score_diff2 = score_ts.diff().diff().dropna()

print("ACF and PACF analysis for GTI Score (second differenced):")
print("Second differenced series:")
print(score_diff2)

# Calculate correlation functions
acf_values = acf(score_diff2, nlags=5)
pacf_values = pacf(score_diff2, nlags=5)

print(f"\nACF values: {acf_values}")
print(f"PACF values: {pacf_values}")

# Test different ARIMA models
print("\n=== ARIMA MODEL SELECTION ===")

# Given the short time series (11 points), we'll test simple models
models_to_test = [
    (0, 2, 0),  # ARIMA(0,2,0) - Random walk with drift
    (0, 2, 1),  # ARIMA(0,2,1) 
    (1, 2, 0),  # ARIMA(1,2,0)
    (1, 2, 1),  # ARIMA(1,2,1)
    (0, 1, 1),  # ARIMA(0,1,1) - Alternative with d=1
    (1, 1, 0),  # ARIMA(1,1,0) - Alternative with d=1
    (1, 1, 1),  # ARIMA(1,1,1) - Alternative with d=1
]

model_results = []

for order in models_to_test:
    try:
        model = ARIMA(score_ts, order=order)
        fitted_model = model.fit()
        
        aic = fitted_model.aic
        bic = fitted_model.bic
        
        model_results.append({
            'order': order,
            'aic': aic,
            'bic': bic,
            'model': fitted_model
        })
        
        print(f"ARIMA{order}: AIC={aic:.2f}, BIC={bic:.2f}")
        
    except Exception as e:
        print(f"ARIMA{order}: Failed to fit - {str(e)}")

# Select best model based on AIC
best_model = min(model_results, key=lambda x: x['aic'])
print(f"\nBest model: ARIMA{best_model['order']} (AIC={best_model['aic']:.2f})")

# Fit the best model
best_arima = best_model['model']
print(f"\nBest ARIMA Model Summary:")
print(best_arima.summary())