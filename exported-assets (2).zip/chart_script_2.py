import plotly.graph_objects as go
import pandas as pd

# Create the data
data = [
    {"Year": 2013, "Residual": -0.289},
    {"Year": 2014, "Residual": 0.070},
    {"Year": 2015, "Residual": 0.110},
    {"Year": 2016, "Residual": -0.077},
    {"Year": 2017, "Residual": -0.062},
    {"Year": 2018, "Residual": -0.025},
    {"Year": 2019, "Residual": -0.083},
    {"Year": 2020, "Residual": -0.296},
    {"Year": 2021, "Residual": 0.069},
    {"Year": 2022, "Residual": 2.428}
]

df = pd.DataFrame(data)

# Create the figure
fig = go.Figure()

# Add the residuals line and markers
fig.add_trace(go.Scatter(
    x=df['Year'],
    y=df['Residual'],
    mode='lines+markers',
    name='Residuals',
    line=dict(color='#1FB8CD', width=3),
    marker=dict(size=8, color='#1FB8CD'),
    hovertemplate='Year: %{x}<br>Residual: %{y:.3f}<extra></extra>'
))

# Add horizontal reference lines
fig.add_hline(y=0, line_dash="solid", line_color="gray", line_width=1)
fig.add_hline(y=0.204, line_dash="dash", line_color="#DB4545", line_width=2)

# Add confidence bands based on std (±1 std and ±2 std)
fig.add_hrect(y0=-0.750+0.204, y1=0.750+0.204, 
              fillcolor="#2E8B57", opacity=0.1, line_width=0)
fig.add_hrect(y0=-1.5+0.204, y1=1.5+0.204, 
              fillcolor="#5D878F", opacity=0.05, line_width=0)

# Update layout
fig.update_layout(
    title='ARIMA Residuals Over Time',
    xaxis_title='Year',
    yaxis_title='Residual',
    showlegend=False
)

# Update traces
fig.update_traces(cliponaxis=False)

# Save as both PNG and SVG
fig.write_image('residuals_chart.png')
fig.write_image('residuals_chart.svg', format='svg')

print("Chart saved successfully!")