# Apply differencing to make series stationary
print("=== APPLYING DIFFERENCING FOR STATIONARITY ===\n")

differenced_data = yearly_data.copy()
differencing_results = {}

for metric in metrics:
    # First difference
    diff_series = yearly_data[metric].diff().dropna()
    
    # Check stationarity after differencing
    is_stationary_diff = check_stationarity(diff_series, f"{metric} (First Difference)")
    differenced_data[f'{metric}_diff'] = yearly_data[metric].diff()
    differencing_results[metric] = {
        'first_diff_stationary': is_stationary_diff,
        'differencing_order': 1 if is_stationary_diff else 2
    }
    
    # If still not stationary, try second difference
    if not is_stationary_diff:
        diff2_series = diff_series.diff().dropna()
        is_stationary_diff2 = check_stationarity(diff2_series, f"{metric} (Second Difference)")
        differencing_results[metric]['second_diff_stationary'] = is_stationary_diff2
        differencing_results[metric]['differencing_order'] = 2 if is_stationary_diff2 else 1

print("\nDifferencing Summary:")
for metric, results in differencing_results.items():
    d_order = results['differencing_order'] 
    print(f"{metric}: Requires d={d_order} for stationarity")

# Focus on GTI Score for detailed ARIMA analysis
print(f"\n=== DETAILED ARIMA ANALYSIS FOR GTI SCORE ===")
score_ts = yearly_data['Score']
print("Original GTI Score time series:")
print(score_ts)