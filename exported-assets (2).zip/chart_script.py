import pandas as pd
import plotly.graph_objects as go

# Create DataFrame from the data
data = [
    {"Year": 2012, "GTI_Score": 2.447, "Type": "Historical"},
    {"Year": 2013, "GTI_Score": 2.364, "Type": "Historical"},
    {"Year": 2014, "GTI_Score": 2.350, "Type": "Historical"},
    {"Year": 2015, "GTI_Score": 2.545, "Type": "Historical"},
    {"Year": 2016, "GTI_Score": 2.578, "Type": "Historical"},
    {"Year": 2017, "GTI_Score": 2.593, "Type": "Historical"},
    {"Year": 2018, "GTI_Score": 2.630, "Type": "Historical"},
    {"Year": 2019, "GTI_Score": 2.588, "Type": "Historical"},
    {"Year": 2020, "GTI_Score": 2.376, "Type": "Historical"},
    {"Year": 2021, "GTI_Score": 2.232, "Type": "Historical"},
    {"Year": 2022, "GTI_Score": 2.168, "Type": "Historical"},
    {"Year": 2023, "GTI_Score": 2.145, "Type": "Forecast", "Lower_CI": 1.964, "Upper_CI": 2.327},
    {"Year": 2024, "GTI_Score": 2.145, "Type": "Forecast", "Lower_CI": 1.811, "Upper_CI": 2.480},
    {"Year": 2025, "GTI_Score": 2.145, "Type": "Forecast", "Lower_CI": 1.709, "Upper_CI": 2.582}
]

df = pd.DataFrame(data)

# Separate historical and forecast data
historical = df[df['Type'] == 'Historical']
forecast = df[df['Type'] == 'Forecast']

fig = go.Figure()

# Add confidence interval first (so it appears behind the lines)
fig.add_trace(go.Scatter(
    x=list(forecast['Year']) + list(forecast['Year'][::-1]),
    y=list(forecast['Upper_CI']) + list(forecast['Lower_CI'][::-1]),
    fill='toself',
    fillcolor='rgba(219, 69, 69, 0.2)',
    line=dict(color='rgba(255,255,255,0)'),
    showlegend=True,
    name='95% CI'
))

# Add historical data
fig.add_trace(go.Scatter(
    x=historical['Year'], 
    y=historical['GTI_Score'],
    mode='lines+markers',
    name='Historical',
    line=dict(color='#1FB8CD', width=3),
    marker=dict(size=6)
))

# Add forecast data
fig.add_trace(go.Scatter(
    x=forecast['Year'], 
    y=forecast['GTI_Score'],
    mode='lines+markers',
    name='Forecast',
    line=dict(color='#DB4545', dash='dash', width=3),
    marker=dict(size=6)
))

fig.update_layout(
    title='GTI Score: Historical & Forecast',
    xaxis_title='Year',
    yaxis_title='GTI Score',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

fig.update_traces(cliponaxis=False)
fig.update_xaxes(dtick=1)

fig.write_image("gti_forecast_chart.png")
fig.write_image("gti_forecast_chart.svg", format="svg")