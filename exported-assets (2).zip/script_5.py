# Model diagnostics and forecasting
print("=== MODEL DIAGNOSTICS ===\n")

# Get residuals
residuals = best_arima.resid

# Calculate diagnostic statistics
ljung_box = acorr_ljungbox(residuals, lags=3, return_df=True)
print("Ljung-Box Test for Residual Autocorrelation:")
print(ljung_box)

# Residual statistics
print(f"\nResidual Statistics:")
print(f"Mean: {residuals.mean():.6f}")
print(f"Std Dev: {residuals.std():.6f}")
print(f"Skewness: {residuals.skew():.6f}")
print(f"Kurtosis: {residuals.kurtosis():.6f}")

# Generate forecasts
print(f"\n=== ARIMA FORECASTING ===")

# Forecast next 3 years (2023-2025)
forecast_steps = 3
forecast = best_arima.forecast(steps=forecast_steps)
forecast_ci = best_arima.get_forecast(steps=forecast_steps).conf_int()

print(f"ARIMA(0,1,1) Forecasts for GTI Score:")
forecast_years = [2023, 2024, 2025]
for i in range(forecast_steps):
    year = forecast_years[i]
    point_forecast = forecast.iloc[i]
    lower_ci = forecast_ci.iloc[i, 0]
    upper_ci = forecast_ci.iloc[i, 1]
    
    print(f"{year}: {point_forecast:.3f} (95% CI: {lower_ci:.3f} - {upper_ci:.3f})")

# Create comprehensive time series analysis for all metrics
print(f"\n=== COMPREHENSIVE TIME SERIES ANALYSIS FOR ALL METRICS ===")

# Analyze trends and patterns
trends_analysis = {}
for metric in metrics:
    ts = yearly_data[metric]
    
    # Calculate trend characteristics
    first_val = ts.iloc[0]
    last_val = ts.iloc[-1]
    max_val = ts.max()
    min_val = ts.min()
    mean_val = ts.mean()
    
    # Linear trend
    x = np.arange(len(ts))
    trend_coef = np.polyfit(x, ts, 1)[0]
    
    trends_analysis[metric] = {
        'start_value': first_val,
        'end_value': last_val,
        'change': last_val - first_val,
        'pct_change': ((last_val - first_val) / first_val * 100) if first_val != 0 else 0,
        'max_value': max_val,
        'min_value': min_val,
        'mean_value': mean_val,
        'trend_slope': trend_coef,
        'trend_direction': 'Increasing' if trend_coef > 0 else 'Decreasing'
    }

print("Trend Analysis Summary (2012-2022):")
print("-" * 80)
for metric, analysis in trends_analysis.items():
    print(f"{metric}:")
    print(f"  Start (2012): {analysis['start_value']:.2f}")
    print(f"  End (2022): {analysis['end_value']:.2f}")
    print(f"  Change: {analysis['change']:.2f} ({analysis['pct_change']:.1f}%)")
    print(f"  Trend: {analysis['trend_direction']} (slope: {analysis['trend_slope']:.2f})")
    print(f"  Range: {analysis['min_value']:.2f} - {analysis['max_value']:.2f}")
    print()

# Export time series data and results
time_series_results = yearly_data.copy()
time_series_results['GTI_Score_Forecast'] = np.nan
time_series_results['Forecast_Lower'] = np.nan
time_series_results['Forecast_Upper'] = np.nan

# Add forecast data
forecast_df = pd.DataFrame({
    'Year': forecast_years,
    'Date': pd.to_datetime(forecast_years, format='%Y'),
    'GTI_Score_Forecast': forecast.values,
    'Forecast_Lower': forecast_ci.iloc[:, 0].values,
    'Forecast_Upper': forecast_ci.iloc[:, 1].values
})

time_series_results.to_csv('Time_Series_Analysis.csv')
forecast_df.to_csv('ARIMA_Forecasts.csv', index=False)

print("Time series analysis exported to 'Time_Series_Analysis.csv'")
print("ARIMA forecasts exported to 'ARIMA_Forecasts.csv'")