import pandas as pd
import plotly.graph_objects as go
import numpy as np

# Create DataFrame from the provided data
data = [
    {"Year": 2012, "Score": 2.447, "Incidents": 4711, "Fatalities": 9227, "Injuries": 16915},
    {"Year": 2013, "Score": 2.364, "Incidents": 4371, "Fatalities": 10317, "Injuries": 19304},
    {"Year": 2014, "Score": 2.350, "Incidents": 3546, "Fatalities": 10129, "Injuries": 13827},
    {"Year": 2015, "Score": 2.545, "Incidents": 3632, "Fatalities": 10881, "Injuries": 17473},
    {"Year": 2016, "Score": 2.578, "Incidents": 4210, "Fatalities": 10372, "Injuries": 10372},
    {"Year": 2017, "Score": 2.593, "Incidents": 4517, "Fatalities": 8932, "Injuries": 14583},
    {"Year": 2018, "Score": 2.630, "Incidents": 4829, "Fatalities": 7480, "Injuries": 10978},
    {"Year": 2019, "Score": 2.588, "Incidents": 4118, "Fatalities": 7193, "Injuries": 9350},
    {"Year": 2020, "Score": 2.376, "Incidents": 4541, "Fatalities": 7433, "Injuries": 7660},
    {"Year": 2021, "Score": 2.232, "Incidents": 5443, "Fatalities": 7328, "Injuries": 7283},
    {"Year": 2022, "Score": 2.168, "Incidents": 3955, "Fatalities": 6701, "Injuries": 5993}
]

df = pd.DataFrame(data)

# Normalize each metric to 0-100 scale for better comparison
def normalize_to_100(series):
    return ((series - series.min()) / (series.max() - series.min())) * 100

df['Score_norm'] = normalize_to_100(df['Score'])
df['Incidents_norm'] = normalize_to_100(df['Incidents'])
df['Fatalities_norm'] = normalize_to_100(df['Fatalities'])
df['Injuries_norm'] = normalize_to_100(df['Injuries'])

# Brand colors from theme
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F']

# Create the multi-line chart
fig = go.Figure()

# Add each metric as a separate line
fig.add_trace(go.Scatter(
    x=df['Year'],
    y=df['Score_norm'],
    mode='lines+markers',
    name='Score',
    line=dict(color=colors[0], width=3),
    marker=dict(size=6),
    hovertemplate='<b>Score</b><br>Year: %{x}<br>Normalized: %{y:.1f}<extra></extra>'
))

fig.add_trace(go.Scatter(
    x=df['Year'],
    y=df['Incidents_norm'],
    mode='lines+markers',
    name='Incidents',
    line=dict(color=colors[1], width=3),
    marker=dict(size=6),
    hovertemplate='<b>Incidents</b><br>Year: %{x}<br>Normalized: %{y:.1f}<extra></extra>'
))

fig.add_trace(go.Scatter(
    x=df['Year'],
    y=df['Fatalities_norm'],
    mode='lines+markers',
    name='Fatalities',
    line=dict(color=colors[2], width=3),
    marker=dict(size=6),
    hovertemplate='<b>Fatalities</b><br>Year: %{x}<br>Normalized: %{y:.1f}<extra></extra>'
))

fig.add_trace(go.Scatter(
    x=df['Year'],
    y=df['Injuries_norm'],
    mode='lines+markers',
    name='Injuries',
    line=dict(color=colors[3], width=3),
    marker=dict(size=6),
    hovertemplate='<b>Injuries</b><br>Year: %{x}<br>Normalized: %{y:.1f}<extra></extra>'
))

# Update layout
fig.update_layout(
    title='Terror Metrics 2012-2022',
    xaxis_title='Year',
    yaxis_title='Normalized (0-100)',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    showlegend=True
)

# Update axes
fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)')
fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)')

# Apply cliponaxis=False for line charts
fig.update_traces(cliponaxis=False)

# Save the chart as both PNG and SVG
fig.write_image("terrorism_trends.png")
fig.write_image("terrorism_trends.svg", format="svg")

print("Chart saved successfully as terrorism_trends.png and terrorism_trends.svg")