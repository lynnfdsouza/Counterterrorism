# Additional ARIMA analysis for other key metrics
print("=== ARIMA ANALYSIS FOR FATALITIES TIME SERIES ===\n")

fatalities_ts = yearly_data['Fatalities']
print("Fatalities time series:")
print(fatalities_ts)

# Test ARIMA models for fatalities (requires d=2 based on stationarity test)
fatalities_models = [
    (0, 2, 0),
    (0, 2, 1), 
    (1, 2, 0),
    (0, 1, 1),  # Alternative with d=1
]

fatalities_results = []

for order in fatalities_models:
    try:
        model = ARIMA(fatalities_ts, order=order)
        fitted_model = model.fit()
        
        aic = fitted_model.aic
        bic = fitted_model.bic
        
        fatalities_results.append({
            'order': order,
            'aic': aic,
            'bic': bic,
            'model': fitted_model
        })
        
        print(f"ARIMA{order}: AIC={aic:.2f}, BIC={bic:.2f}")
        
    except Exception as e:
        print(f"ARIMA{order}: Failed - {str(e)}")

if fatalities_results:
    best_fatalities_model = min(fatalities_results, key=lambda x: x['aic'])
    print(f"\nBest Fatalities Model: ARIMA{best_fatalities_model['order']}")
    
    # Generate forecasts for fatalities
    fatalities_forecast = best_fatalities_model['model'].forecast(steps=3)
    fatalities_ci = best_fatalities_model['model'].get_forecast(steps=3).conf_int()
    
    print("Fatalities Forecasts (2023-2025):")
    for i, year in enumerate([2023, 2024, 2025]):
        point_est = fatalities_forecast.iloc[i]
        lower_ci = fatalities_ci.iloc[i, 0]
        upper_ci = fatalities_ci.iloc[i, 1]
        print(f"{year}: {point_est:.0f} (95% CI: {lower_ci:.0f} - {upper_ci:.0f})")

print(f"\n=== INCIDENT ANALYSIS ===")
incidents_ts = yearly_data['Incidents']

# Simple trend analysis for incidents
incidents_change = incidents_ts.iloc[-1] - incidents_ts.iloc[0]
incidents_pct_change = (incidents_change / incidents_ts.iloc[0]) * 100

print(f"Incidents trend: {incidents_change:.0f} change ({incidents_pct_change:.1f}%)")
print(f"Peak incidents: {incidents_ts.max():.0f} in {yearly_data.index[incidents_ts.argmax()].year}")
print(f"Lowest incidents: {incidents_ts.min():.0f} in {yearly_data.index[incidents_ts.argmin()].year}")

# Summary of all time series characteristics
print(f"\n=== COMPREHENSIVE TIME SERIES SUMMARY ===")
summary_stats = pd.DataFrame({
    'Mean': yearly_data[metrics].mean(),
    'Std_Dev': yearly_data[metrics].std(),
    'Min': yearly_data[metrics].min(), 
    'Max': yearly_data[metrics].max(),
    'Trend_2012_2022': [(yearly_data[metric].iloc[-1] - yearly_data[metric].iloc[0]) / yearly_data[metric].iloc[0] * 100 for metric in metrics]
})

print("Statistical Summary (2012-2022):")
print(summary_stats.round(2))