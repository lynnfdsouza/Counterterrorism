# Adjust for short time series (only 9 observations after second differencing)
print("=== ARIMA MODEL IDENTIFICATION (ADJUSTED FOR SHORT SERIES) ===\n")

score_diff2 = score_ts.diff().diff().dropna()
print(f"Second differenced series length: {len(score_diff2)}")
print("Second differenced GTI Score:")
print(score_diff2)

# Calculate ACF and PACF with appropriate lags for short series
max_lags = min(3, len(score_diff2)//2)
if max_lags > 0:
    acf_values = acf(score_diff2, nlags=max_lags)
    pacf_values = pacf(score_diff2, nlags=max_lags)
    
    print(f"\nACF values (nlags={max_lags}): {acf_values}")
    print(f"PACF values (nlags={max_lags}): {pacf_values}")

# Test ARIMA models suitable for short time series
print("\n=== ARIMA MODEL SELECTION FOR SHORT TIME SERIES ===")

models_to_test = [
    (0, 1, 0),  # Random walk
    (0, 1, 1),  # ARIMA(0,1,1) 
    (1, 1, 0),  # ARIMA(1,1,0)
    (0, 2, 0),  # ARIMA(0,2,0) 
    (1, 0, 0),  # AR(1)
    (0, 0, 1),  # MA(1)
]

model_results = []

for order in models_to_test:
    try:
        model = ARIMA(score_ts, order=order)
        fitted_model = model.fit()
        
        aic = fitted_model.aic
        bic = fitted_model.bic
        loglik = fitted_model.llf
        
        model_results.append({
            'order': order,
            'aic': aic,
            'bic': bic,
            'loglik': loglik,
            'model': fitted_model
        })
        
        print(f"ARIMA{order}: AIC={aic:.3f}, BIC={bic:.3f}, LogLik={loglik:.3f}")
        
    except Exception as e:
        print(f"ARIMA{order}: Failed to fit - {str(e)}")

if model_results:
    # Select best model based on AIC
    best_model = min(model_results, key=lambda x: x['aic'])
    print(f"\nBest model: ARIMA{best_model['order']} (AIC={best_model['aic']:.3f})")
    
    # Detailed analysis of best model
    best_arima = best_model['model']
    print(f"\n=== BEST ARIMA MODEL ANALYSIS ===")
    print(best_arima.summary())