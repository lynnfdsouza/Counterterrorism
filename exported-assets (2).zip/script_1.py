# Prepare time series for different metrics
yearly_data['Date'] = pd.to_datetime(yearly_data['Year'], format='%Y')
yearly_data = yearly_data.set_index('Date').sort_index()

print("=== TIME SERIES ANALYSIS FOR MULTIPLE METRICS ===\n")

# Function to check stationarity
def check_stationarity(timeseries, title):
    print(f"Stationarity Test for {title}:")
    
    # Perform Augmented Dickey-Fuller test
    result = adfuller(timeseries.dropna())
    print(f'ADF Statistic: {result[0]:.6f}')
    print(f'p-value: {result[1]:.6f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print(f'\t{key}: {value:.3f}')
    
    if result[1] <= 0.05:
        print("✓ Series is stationary (reject null hypothesis)")
    else:
        print("✗ Series is non-stationary (fail to reject null hypothesis)")
    print("-" * 50)
    
    return result[1] <= 0.05

# Check stationarity for each metric
metrics = ['Score', 'Incidents', 'Fatalities', 'Injuries', 'Hostages']
stationarity_results = {}

for metric in metrics:
    is_stationary = check_stationarity(yearly_data[metric], metric)
    stationarity_results[metric] = is_stationary

print("\nStationarity Summary:")
for metric, is_stationary in stationarity_results.items():
    status = "Stationary" if is_stationary else "Non-stationary"
    print(f"{metric}: {status}")