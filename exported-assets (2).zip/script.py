import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, acf, pacf
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.stats.diagnostic import acorr_ljungbox
from sklearn.metrics import mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings('ignore')

# Load and prepare time series data
df = pd.read_excel('Global-Terrorism-Index-2023.xlsx')

print("=== TIME SERIES DATA PREPARATION ===")
print(f"Dataset shape: {df.shape}")
print(f"Years available: {sorted(df['Year'].unique())}")

# Create time series aggregations
yearly_data = df.groupby('Year').agg({
    'Score': 'mean',
    'Incidents': 'sum', 
    'Fatalities': 'sum',
    'Injuries': 'sum',
    'Hostages': 'sum'
}).reset_index()

print("\nYearly aggregated data:")
print(yearly_data)